version.compare <- function(m, methods=0, times){
  assets <- GetAssets(1:m, assets1457)
  micro <- microbenchmark(r1 <- CLA$M2(assets$mu, assets$covar, assets$lB, assets$uB),
                          r2 <- CLA$M4(assets$mu, assets$covar, assets$lB, assets$uB),
                          times = times)
  list(micro = micro, is.equal = all.equal(r1, r2),
       weight.equal = all.equal(r1$weights_set_purge, r2$weights_set_purge))
  
}