debug(CLA$M4)
CLA$M4(assets20$mu, assets20$covar, assets20$lB, assets20$uB)
## enter (twice ?)
debug(Method4$cla.solver)

