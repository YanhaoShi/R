if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################



assets <- GetAssets(1:20, assets1457)
mu <- assets$mu; covar <- assets$covar; lB <- assets$lB; uB <- assets$uB
r5 <- CLA$M5(mu, covar, lB, uB)
r4 <- CLA$M4(mu, covar, lB, uB)
r5$free_indices
r4$free_indices
all.equal(r5$free_indices, r4$free_indices)
r4$lambdas ; r2$lambdas



lapply(seq(20, 220, 50), function(x) version.compare(x,times = 1)$is.equal)



version.compare(50, times = 1, versions = c(4,5))



#5: 4�����ڸĽ�

#4meeting�ĵ�
# 2/4 same, maybe differnet for small numbers

source("main.R")
lapply(seq(20, 120, 20), function(x) {
  version.compare(x, 1, versions = c(4,5))
})
