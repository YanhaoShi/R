assets20 <- GetAssets(1:20, assets1457)
r20 <- CLA$M4(assets20$mu, assets20$covar, assets20$lB, assets20$uB)
assets50 <- GetAssets(1:50, assets1457)
r50 <- CLA$M4(assets50$mu, assets50$covar, assets50$lB, assets50$uB)



f_move <- function(free_indices){
  n <- length(free_indices)
  f.label <- c()
  for(i in 2: (n-1)){
    s <- sign(length(free_indices[[i]]) - length(free_indices[[i-1]]))
    if(abs(s)!=1) stop("error: should add or remove one free asset")
    if(s > 0){
      f.label[i] <- setdiff(free_indices[[i]], free_indices[[i-1]])*s
    }else if(s < 0){
      f.label[i] <- setdiff(free_indices[[i-1]], free_indices[[i]])*s
    }
  }
  f.label
}

f.label <- f_move(r20$free_indices)
f.label <- f_move(r50$free_indices)

plot_move <- function(free_indices, weights_set){ 
  f.label <- f_move(free_indices)
  n <- length(free_indices)
  y <- log(1e-10 + abs(colSums(weights_set) - 1))
  plot(y, ylim = c(min(y), max(y) +5), type = "o", pch =16,
       col = c(1, sign(f.label[-1])+3 ),
       xlab = "step", main = "logged deviation from 1",
       ylab = "")
  abline(h =  log(1e-10), col = "grey")
  text(2:(n-1), log(1e-10 + abs(colSums(weights_set) - 1))[-1], 
       f.label[-1], pos = 3, col = sign(f.label[-1])+3  )
  legend("topleft", legend = c("add f", "remove f"), col = c(4,2), pch = 16,
         bg = "transparent", bty = "n")
}

plot_move(r20$free_indices, r20$weights_set)
plot_move(r50$free_indices, r50$weights_set)

w1 <-CLA$M1(assets50$mu, assets50$covar, assets50$lB, assets50$uB)[[3]]
colSums(w1)

plot(r20$weights_set[,2], ylim = c(0,0.075), pch =16)
segments(1:20, rep(0,20), 1:20, rep(0.075, 20), col = "red")



r20.5 <- CLA$M5(assets20$mu, assets20$covar, assets20$lB, assets20$uB)
colSums(r20.5$weights_set)
colSums(r20$weights_set)
