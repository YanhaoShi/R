# eg
company79_set1 <- readRDS(d.file("Company79_set1.rds", exist = FALSE))
campany79_data1 <- readRDS(d.file("Company79_data1.rds", exists = FALSE))
company285_set1 <- readRDS(d.file("Company285_set1.rds", exists = FALSE))

w.cla <- company79_set1$weights$w.cla
w.qp <- company79_set1$weights$w.qp


compareEF(w.qp, w.cla, campany79_data1$mu, campany79_data1$covar)

Total.plot(company79_set1$MS)

Total.plot(company79_set1$MS[1])

plot(colSums(company79_set1$result.cla$weights_set))

plot(1e-17+abs(1-colSums(company79_set1$result.cla$weights_set)), log = "y")

plot(1e-17+abs(1-colSums(company285_set1$result.cla$weights_set)), log = "y",
     type = "o")

a <- GetAssets(sample.int(1457,20), assets1457)
an <- CLA$M2(a$mu, a$covar, a$lB, a$uB)
an$weights_set
plot(1e-17+abs(1-colSums(an$weights_set)), log = "y",
     type = "o")
an$free_indices
Total.plot(MS(an$weights_set, a$mu, a$covar))




hyperbolic(mean(c(w.cla[,1], w.cla[,2])), w.cla[,1], w.cla[,2], 
           campany79_data1$mu, campany79_data1$covar)


w1 <- w.cla[,2]; w2 <- w.cla[,3]
Mu <- campany79_data1$mu; Cov <- campany79_data1$covar

  MS(w.cla, Mu, Cov)[,"Mu"]





function(mu_in, w1, w2, Mu, Cov){  
  
  
  w_in <- (1-lambda)*w1 + lambda*w2
  sum(w_in * (Cov %*% w_in))  # sig2 of mu_in
}


mu1 <- sum(Mu * w1)   # mu1 > mu2
mu2 <- sum(Mu * w2)

mu_in <- mean(mu1, mu2)
lambda <- (mu_in - mu1)/(mu2 - mu1)

mu_in
sum(((1-(x - mu1)/(mu2 - mu1))*w1 + (x - mu1)/(mu2 - mu1)*w2) * Cov %*% 
      ((1-(x - mu1)/(mu2 - mu1))*w1 + (x - mu1)/(mu2 - mu1)*w2))

x <- mu_in
curve(sum(((1-(x - mu1)/(mu2 - mu1))*w1 + (x - mu1)/(mu2 - mu1)*w2) * Cov %*% 
      ((1-(x - mu1)/(mu2 - mu1))*w1 + (x - mu1)/(mu2 - mu1)*w2)),
      mu1, mu2)


curve((x - mu1)/(mu2 - mu1)*w1, mu2, mu1)




y <- 1
curve(sin(x)+y, y, 2)
curve(sin(y), 1, 2)



op <- par(mfrow = c(2,1), mgp = c(2,.8,0), mar = 0.1+c(3,3,3,1))
n <- 9
x <- 1:n
y <- rnorm(n)
plot(x, y, main = paste("spline[fun](.) through", n, "points"))
lines(spline(x, y))
lines(spline(x, y, n = 201), col = 2)

ms79 <- company79_set1$MS$ms.cla
plot(x = ms79[, "Sig2"], y = ms79[, "Mu"] )
lines(spline(x = ms79[, "Sig2"], y = ms79[, "Mu"], n = 201), col = 2)



f <- function(x = y+2, y = x+1){ x+y}
f(2, )
f(, 3)

