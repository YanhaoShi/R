if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
#############################################################################
assets20 <- GetIndex(1:20, assets1457)
assets50 <- GetIndex(1:50, assets1457)

result20.list <- lapply(CLA, function(fun) 
  fun(assets20$mu, assets20$covar, assets20$lB, assets20$uB))
result50.list <- lapply(CLA, function(fun) 
  fun(assets50$mu, assets50$covar, assets50$lB, assets50$uB))
#############################################################################
rt3 <- Result_table(result20.list$M3, assets20$mu, assets20$covar)
rt4 <- Result_table(result20.list$M4, assets20$mu, assets20$covar) # ==rt3
all.equal(rt3, rt4)
rt5 <- Result_table(result20.list$M5, assets20$mu, assets20$covar)



rt4
## rows 8..10  and then 12..14 are identical(unequal in process, ~ 1e-17)
rt4[8, "lambda"] - rt4[9, "lambda"]; rt4[9, "lambda"] - rt4[10, "lambda"]
rt4[12, "lambda"] - rt4[13, "lambda"]; rt4[13, "lambda"] - rt4[14, "lambda"]

rt4[, "lambda"] 
rt5[, "lambda"]
plot_EFpurge(result20.list$M4, assets20$mu, assets20$covar)
plot_EFpurge(result20.list$M5, assets20$mu, assets20$covar) # no changes

unique(result20.list$M5$weights_set)


version.compare(50, 3, c(4, 5))$micro # ver5: less steps, hence faster

###########################################################################

debugonce(Env6$cla.solver)
result <- Env6$cla.solver(mu*10, covar*10^2, lB, uB)
Result_table(result, mu*10, covar*100) # lambda(*10)gamma change(*100)









##################################
mu <- assets20$mu; covar <- assets20$covar;
lB <- assets20$lB; uB <- assets20$uB

purgeChull = function(weights_set, mean, covar){
  Sig2 <- colSums(weights_set *(covar %*% weights_set) )
  Mu <- t(weights_set) %*% mean
  ch <- sort(chull(cbind(Sig2, Mu)))
  Mu <-     Mu[ch]
  Sig2 <- Sig2[ch]
  index.chull <- ch[Sig2 <= Sig2[which.max(Mu)]]
  index.chull
}
purgeChull = function(weights_set, mean, covar){
  Sig2 <- colSums(weights_set *(covar %*% weights_set) )
  Mu <- t(solution_set) %*% mean
  ch <- sort(chull(cbind(Sig2, Mu)))
  index.chull <- ch[Sig2[ch] <= Sig2[which.max(Mu)]]
  index.chull
}
i <- purgeChull(result20.list$M2$weights_set, assets20$mu, assets20$covar)
MS_plot(MS(result20.list$M2$weights_set[,i], assets20$mu, assets20$covar))
plot_EFpurge(result20.list$M2, assets20$mu, assets20$covar)



order(mu, decreasing = T) #...12, 3, 4...
min(mu[12] - mu[3], mu[3] - mu[4]) # 12

f <- Env5$initAlgo(mu, lB, uB)$index
w <- as.matrix(Env5$initAlgo(mu, lB, uB)$weights)
# w[3] increasing, w[12] decreasing
d <- min(uB[3] - w[3], uB[12] - lB[12]) # movement
w[3] <- w[3] + d
w[12] <- w[12] - d
f <- 12
