version.compare <- function(assets.number, times, versions){
  assets <- GetAssets(1:assets.number, assets1457)
  micro <- microbenchmark(r1 <- CLA[[paste("M", versions[1], sep = "")]](assets$mu, assets$covar, assets$lB, assets$uB),
                          r2 <- CLA[[paste("M", versions[2], sep = "")]](assets$mu, assets$covar, assets$lB, assets$uB),
                          times = times)
  list(micro = micro, is.equal = all.equal(r1, r2),
       weight.equal = all.equal(r1$weights_set_purge, r2$weights_set_purge),
       free_indices.equal = all.equal(r1$free_indices, r2$free_indices))
  
}



# (1) purgeNumErr
testPurgeNumErr <- function(result, lB, uB){
  free_indices <- result$free_indices
  gammas <- result$gammas
  lambdas <- result$lambdas
  weights_set <- result$weights_set
  ind.old <- Env1.2$purgeNumErr(free_indices, gammas, lambdas, 
                                lB, uB, weights_set, 1e-09)$index
  ind.old <- seq_along(ind.old) - 1 + ind.old
  
  ind <- which(Env2$purgeNumErr(lB = lB, uB = uB, weights_set = weights_set, 
                                tol.s = 1e-09, tol.b = 1e-10))
  ind.new <- seq_len(ncol(weights_set))[-ind]
  list(ind.old = ind.old, ind.new = ind.new) # return indices should remove
}

f_change <- function(free_indices){ # free index change of result$free_indices
  n <- length(free_indices)
  f.label <- c()
  for(i in 2: n){
    if(!anyNA(free_indices[[i]])){
      s <- sign(length(free_indices[[i]]) - length(free_indices[[i-1]]))
      if(s == 0){
        f.label[i] <- NA
      } else if(s > 0){
        diff <- setdiff(free_indices[[i]], free_indices[[i-1]])*s
        f.label[i] <- paste0("(", paste(diff, collapse=","), ")") 
      }else if(s < 0){
        diff <- setdiff(free_indices[[i-1]], free_indices[[i]])*s
        f.label[i] <- setdiff(free_indices[[i-1]], free_indices[[i]])*s
        f.label[i] <- paste0("(", paste(diff, collapse=","), ")")
      }
    }else f.label[i] <- NA
  }
  f.label
} 

plot_weight_f <- function(result, lB, uB){
  
  free_indices = result$free_indices
  weights_set = result$weights_set
  f.label <- f_change(result)
  n <- length(free_indices)
  y <- log(1e-10 + abs(colSums(weights_set) - 1))
  plot(y, ylim = c(min(y), max(y) +10), type = "o", pch =16,
       col = c(1, sign(f.label[-1])+3 ),
       xlab = "step", main = "PurgeNumErr: logged deviation from 1",
       ylab = expression(10^y))
  text(2:(n-1), log(1e-10 + abs(colSums(weights_set) - 1))[-1], 
       f.label[-1], pos = 3, col = sign(f.label[-1])+3  )
  legend("topleft", legend = c("add f", "remove f"), col = c(4,2), pch = 16,
         bg = "transparent", bty = "n")
}

plot_weight_sum <- function(result, lB, uB){
  ind <- testPurgeNumErr(result, lB, uB)
  ind.old <- ind$ind.old
  ind.new <- ind$ind.new
  free_indices = result$free_indices
  weights_set = result$weights_set
  f.label <- f_change(result)
  n <- length(free_indices)
  dev <- abs(colSums(weights_set) - 1) # deviation from 1
  y <- log(1e-10 + dev)
  col2 <- rep("grey", n)
  col2[ind.old] <- 
    col2[ind.new] <- adjustcolor("purple", 0.8)
  plot(y, ylim = c(min(y), max(y) +10), type = "o", pch =16,
       col = "grey",
       xlab = "step", main = "PurgeNumErr: Step to be purged",
       ylab = expression(10^y))
  points(seq_len(n)[ind.old], y[ind.old], col = "blue3", pch = 15, cex = 1.5)
  points(seq_len(n)[ind.new], y[ind.new], col = "red", pch = 18)
  text(ind.new, y[ind.new], 
       ind.new, pos = 3, col = "red"  )
  legend("topleft", legend = c("old PurgeNumErr", "new PurgeNumErr"), 
         col = c("blue3", "red"), 
         pch = c(15, 18), bg = "transparent", bty = "n")
}

######################################################################################
# (2) purgeChull
testPurgeChull <- function(result, mu, covar){
  free_indices <- result$free_indices
  gammas <- result$gammas
  lambdas <- result$lambdas
  weights_set <- result$weights_set
  ind <- Env1.2$purgeExcess(mu = mu, lambdas = lambdas, gammas = gammas, 
                                free_indices = free_indices, 
                                weights_set = weights_set)$k
  ind.excess <- seq_len(ncol(weights_set))[-ind]
  ind.chull <- purgeChull(weights_set , mu, 
                  covar = covar)
  ind.slope <- Env4$purgeSlope(weights_set = weights_set ,mu = mu, 
                               covar = covar)
  list(ind.excess = ind.excess, ind.chull = ind.chull,
       ind.slope = ind.slope) #return keep
}

plot_EFpurge <- function(result, mu, covar){
  weights_set <- result$weights_set
  ms <- MS(weights_set, mu, covar)
  ind <- testPurgeChull(result, mu, covar)
  MS_plot(ms, type = "p", pch = 1)
  MS_points(ms[ind$ind.excess, ], col = "green", pch = 16, cex = 1, lty =2)
  MS_points(ms[ind$ind.chull, ], col = adjustcolor("blue", 0.5),
            pch = 15, cex = 1.2, lty = 3)
  MS_points(ms[ind$ind.slope, ], col = adjustcolor("red", 0.8), 
            pch = 17, cex = 1, lty = 1)
  legend("bottomright", 
         legend = c("unpurged", "purgeExcess", "purgeChull", "purgeSlope"),
         col = c("black", "green", "blue", "red"), pch = c(1, 16, 15, 17), 
         bg = "transparent", bty = "n", lty = c(0, 2, 3, 1))
}

#############################################################################
# (3) solve covarF
testInv <- function(result, mu, covar){
  free_indices <- result$free_indices
  weights_set <- result$weights_set
  n <- ncol(result$weights_set)
  inv_covarF <- function(col, inv){
    w <- weights_set[, col]
    f <- free_indices[[col]]
    get <- Env3$getMatrices(mu, covar, w, f)
    covarF <- get$covarF
    covarFB <- get$covarFB
    muF <- get$muF
    wB <- get$wB
    if(inv == 1) chol2inv(chol(covarF)) %*% cbind(1, muF, covarFB %*% wB)
    else if(inv == 2) solve(covarF) %*% cbind(1, muF, covarFB %*% wB)
    else if(inv == 3) solve(covarF, cbind(1, muF, covarFB %*% wB))
  }
  micro <- microbenchmark(inv1 = inv1 <- sapply(1:(n-1), function(col) inv_covarF(col, 1)),
                          inv2 = inv2 <- sapply(1:(n-1), function(col) inv_covarF(col, 2)),
                          inv3 = inv3 <- sapply(1:(n-1), function(col) inv_covarF(col, 3)))
  is.allequal <- all.equal(inv1, inv3) & all.equal(inv2, inv3)
  list(micro = micro, is.allequal = is.allequal)
}

