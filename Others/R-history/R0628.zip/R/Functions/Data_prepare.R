# 1. Company data
 # Raw company data
if(!file.exists(d.file("company_assets.rds", exists = FALSE))){
  saveRDS(read.table(d.file('03-02_CLA_Data_Tot.csv'), header = TRUE, sep = ','), 
          d.file("company_assets.rds", exists = FALSE))
}
company_assets <- readRDS(d.file("company_assets.rds", exists = FALSE))

 # Total assets: assets 1457 
if(!file.exists(d.file("assets1457.rds", exists = FALSE))){
  transData <- function(d){
    n <- ncol(company_assets)
    assets <- as.matrix(t(d[1:3, 1:n]))
    colnames(assets) <- c("mu", "lB", "uB")
    covar <- as.matrix(d[4:(n+3), 1:n ])
    rownames(covar) <- colnames(covar)
    list(assets = assets, covar = covar)
  }
  # for function input
  getData <- function(d){
    row.names(d$assets) <- NULL
    mu <- as.matrix(d$assets[, "mu"])
    lB <- as.matrix(d$assets[, "lB"])
    uB <- as.matrix(d$assets[, "uB"])
    colnames(d$covar) <- NULL
    rownames(d$covar) <- NULL
    covar <- d$covar
    list(mu = mu, lB = lB, uB = uB, covar = covar)
  }
  
  if(!file.exists(d.file("trans_company_assets.rds", exists = FALSE))){
    saveRDS(transData(company_assets), 
            d.file("trans_company_assets.rds", exists = FALSE))
  }
  saveRDS(getData(transData(company_assets)), d.file("assets1457", exists = FALSE))
}
assets1457 <- readRDS(d.file("assets1457.rds", exists = FALSE))
# the corresponding assets under a given set of indices from the total assets
GetAssets <- function(ind, total_assets){
  list(mu = total_assets$mu[ind, , drop = FALSE], 
       lB = total_assets$lB[ind, , drop = FALSE], 
       uB = total_assets$uB[ind, , drop = FALSE], 
       covar = total_assets$covar[ind, ind])
}
######################################################################################
# 2. FRAPO data
transIndex <- function(Index, lB = as.matrix(rep(1e-8, ncol(Index))), 
                       uB = as.matrix(rep(0.075, ncol(Index)))){
  n <- ncol(Index)
  Index1 <- sapply(1:n, function(x) Index[-1,x]/Index[-nrow(Index),x]-1 )
  mu <- as.matrix(apply(Index1, 2, mean))
  # -> 264 observations
  covar <- cov(Index1)
  list(mu = mu, covar = covar, lB = lB, uB = uB)
}

GetIndex <- function(ind, Index.trans){
  mu <- Index.trans$mu[ind]
  covar <- Index.trans$covar[ind, ind]
  lB <- Index.trans$lB[ind]
  uB <- Index.trans$uB[ind]
  list(mu = as.matrix(mu), covar = covar, lB = lB, uB = uB)
}



