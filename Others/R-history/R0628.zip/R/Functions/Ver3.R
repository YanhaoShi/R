Env3 <- funEnv( 
  info = "benchmark, colSums = 1", 
  # Initialize the weight -- Find first free weight
  initAlgo = function(mu, lB, uB ){
    #New-ordered return, lB, uB with decreasing return  
    w <- c()
    index.new <- order(mu,decreasing = T) # new order with decreasing return
    lB.new <- lB[index.new]
    uB.new <- uB[index.new]
    # free weight - starting solution
    i.new <- 0
    w.new <- lB.new # initialy
    while(sum(w.new) < 1) {
      i.new <- i.new + 1
      w.new[i.new] <- uB.new[i.new]
    }
    w.new[i.new] <- 1 - sum(w.new[-i.new])
    w[index.new] <- w.new                #back to original order
    i <- index.new[i.new] 
    list(index = i, weights = w)         # return the index of first free asset and vector w
  }, 
  
  # computeW -----------------------------------------------------------------
  # compute gamma #(Bailey and Lopez de Prado 2013, 11)
  computeW = function(lam, get, muF.def){
    covarFB <- get$covarFB
    wB <- get$wB
    covarF <- get$covarF
    if(missing(muF.def)) {muF <- get$muF} else {muF <- muF.def}
    
    #1) compute gamma
    inv <- solve(covarF, cbind(1, muF, covarFB %*% wB)) #remove name
    g1 <- sum(inv[,2])  
    g2 <- sum(inv[,1])
    g3 <- sum(wB)
    w1 <- inv[,3]
    g4 <- sum(w1)
    g <- as.numeric(-lam*g1/g2+(1-g3+g4)/g2)
    
    #2) compute weights
    w2 <- inv[,1]
    w3 <- inv[,2]
    list(wF = -w1+g*w2+lam*w3, gamma = g)
  },
  
  # computeLambda --------------------------------------------------------------
  # (Niedermayer and Niedermayer 2007, 10)
  # bound to free
  computeLambda = function(get, i, bi){
    covarFB <- get$covarFB
    muF <- get$muF
    wB <- get$wB
    covarF <- get$covarF
    #1) C
    inv <- solve(covarF, cbind(1, muF, covarFB %*% wB))
    c1 <- sum(inv[,1])
    c2i <-  inv[i, 2]
    c3 <- sum(inv[,2])
    c4i <- inv[i, 1]
    Ci <- -c1*c2i + c3*c4i  
    if(Ci == 0) 0
    #3) lambda
    l1 <- sum(wB)
    l3 <- inv[,3]
    l2 <- sum(l3)
    ((1-l1+l2)*c4i-c1*(bi+inv[i,3]))/Ci # return lambda
  },
  
  # free to bound
  #return a list of lambda and b with length(b)
  lcomputeLambda = function(get,i,bi.lB, bi.uB){
    covarFB <- get$covarFB
    muF <- get$muF
    wB <- get$wB
    covarF <- get$covarF
    
    #1) C
    lambda <- c()
    bi.output <- c()
    inv <- solve(covarF, cbind(1, muF, covarFB %*% wB))
    c1 <- sum(inv[,1])
    c2i <-  inv[i, 2]
    c3 <- sum(inv[,2])
    c4i <- inv[i, 1]
    Ci <- -c1*c2i + c3*c4i  
    k <- which(Ci == 0)
    lambda[k] <- 0
    bi.output[k] <- 0
    
    #2) bi
    for (tt in seq_along(Ci))
      bi.output[tt] <- ifelse(Ci[tt] > 0, bi.uB[tt], bi.lB[tt])
    
    #3) lambda
    l1 <- sum(wB)
    l3 <- inv[,3]
    l2 <- sum(l3)
    return(list(lambda = ((1-l1+l2)*c4i-c1*(bi.output+inv[i,3]))/Ci, bi = bi.output))
    # return boundary
  },
  # getMatrices --- -------------------------------------------------------------
  getMatrices = function(mu, covar, w, f){
    # Slice covarF,covarFB,covarB,muF,muB,wF,wB
    covarF <- covar[f,f]
    muF <- mu[f]
    b <- (seq_along(mu))[-f]
    covarFB <- covar[f,b]
    wB <- w[b]
    return(list(covarF=covarF,covarFB=covarFB,muF=muF,wB=wB))
  },
  
  # purgeNumErr ---  -------------------------------------------------------------
  # Purge violations: remove w if sum(w)!=1, w<lB, w>uB
  purgeNumErr = function(lB, uB, weights_set, 
                                          tol.s, tol.b){ 
    n <- ncol(weights_set) 
    index.s <- abs(colSums(weights_set)-1) < tol.s
    m_lB <- matrix(rep(lB, n), ncol = n)
    m_uB <- matrix(rep(uB, n), ncol = n) 
    m_logical <- (weights_set - m_lB > -tol.b) | (weights_set - m_uB < tol.b)
    index.b <- apply(m_logical, 2, any)
    index.s & index.b
  }, 
  
  ## convex hull
  purgeChull = function(weights_set, mu, covar){
    ms <- MS(weights_set, mu, covar)
    Sig <- ms[, "Sig"]
    Mu <- ms[, "Mu"]
    ch <- sort(chull(ms))
    index.chull <- ch[Sig[ch] <= Sig[which.max(Mu)]] # top
    index.chull # return indices should keep
  },
 
  cla.solver = function(mu, covar,lB, uB){                                             
    # Compute the turning points, free sets and weights
    f <- initAlgo(mu, lB, uB)$index
    w <- as.matrix(initAlgo(mu, lB, uB)$weights)
    weights_set <- w # store solution
    lambdas <- NA  # The first step has no lambda or gamma, add NA instead.
    gammas <- NA#########
    free_indices <- list(f) ### 
    lam <- 1 # set non-zero lam
    while ( lam!=0 && length(f) < length(mu)) {
      # 1) case a): Bound one free weight 
      l_in <- 0
      if(length(f) > 1 ){  
        get1 <- getMatrices(mu, covar, w, f)
        compl <- lcomputeLambda(get = get1, i = seq_along(f),
                                bi.lB = lB[f], bi.uB = uB[f])
        lam_in<- compl$lambda
        bi <- compl$bi
        k <- which.max(lam_in)
        i_in <- f[k]
        bi_in <- bi[k]
        l_in <- lam_in[k]
      }  
      
      # 2) case b): Free one bounded weight
      b <- seq_along(mu)[-f]
      lam_out <- sapply(b, function(bi) {
        get_i <- getMatrices(mu, covar, w, c(f,bi))
        computeLambda(get = get_i, i = length(get_i$muF), bi = w[bi])
      })
      
      if (length(lambdas) > 1 && any(!(sml <- lam_out < lam))) { 
        lam_out <- lam_out[sml]
        b       <- b      [sml]
      }
      k <- which.max(lam_out)
      i_out <- b      [k] # one only !
      l_out <- lam_out[k]
      
      # 3) decide lambda  
      lam <- max(l_in, l_out, 0)
      if(lam > 0) { # remove i_in from f; or add i_out into f
        if(l_in > l_out ){
          f <- f[f != i_in]
          w[i_in] <- bi_in  # set value at the correct boundary
        } 
        else {
          f <- c(f,i_out)
        }
        getM <- getMatrices(mu, covar, w, f)
        temp_compW <- computeW(lam, get = getM)
      }
      else{ #4) if max(l_in, l_out) < 0, "stop" when at the min var solution! 
        temp_compW <- computeW(lam = lam, get = get1, muF.def = 0)
      } 
      
      wF <- temp_compW$wF
      g <- temp_compW$gamma
      w[f] <- wF[seq_along(f)] 
      
      lambdas <- c(lambdas, lam)
      weights_set <- cbind(weights_set, w) # store solution
      gammas <- c(gammas, g)
      free_indices <- c(free_indices, list(f))
    } #end While  
    
    free_indices[[length(free_indices)]] <- NA
    
    # purge 
    #i <- purgeNumErr(lB, uB, weights_set, 1e-9, 1e-10) 
    #weights_set_purge <- weights_set[,i]
    #lambdas_purge <- lambdas[i]
    #gammas_purge <- gammas[i]
    #free_indices_purge <- free_indices[i]
    
    j <- purgeChull(weights_set, mu, covar)
    weights_set_purge <- weights_set[,j] 
    lambdas_purge <- lambdas[j] 
    gammas_purge <- gammas[j]
    free_indices_purge <- free_indices[j] 
    
    list(weights_set_purge = weights_set_purge, free_indices_purge = free_indices_purge, 
         gammas_purge = gammas_purge, lambdas_purge = lambdas_purge,
         weights_set = weights_set, free_indices=free_indices, 
         gammas = gammas, lambdas = lambdas)
  }
)