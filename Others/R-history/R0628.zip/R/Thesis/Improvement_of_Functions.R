if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
#############################################################################
Ver.info #view version information
verind

# Example: the first 20 assets
assets20 <- GetIndex(1:20, assets1457)
assets50 <- GetIndex(1:50, assets1457)
result20.list <- lapply(CLA, function(fun) 
          fun(assets20$mu, assets20$covar, assets20$lB, assets20$uB))
result50.list <- lapply(CLA, function(fun) 
  fun(assets50$mu, assets50$covar, assets50$lB, assets50$uB))

############################################################################
# (1) PurgeNumErr 
# compare function from Ver 1.2 & Ver 2
# test using results from Ver 2

# return indices purged by PurgeNumErr function from Ver1.2 and Ver 2
testPurgeNumErr(result20.list$M2, assets20$lB, assets20$uB)

# index change from each step (NA for first and last step)
f_change(result20.list$M2)

pdf("D:/Master Thesis/MyThesis/Pictures/purgeNumErr_wf20.pdf",
    width = 10, height = 5) 
plot_weight_f(result20.list$M2, assets50$lB, assets50$uB)
dev.off()

pdf("D:/Master Thesis/MyThesis/Pictures/purgeNumErr_wsum20.pdf",
    width = 10, height = 5) 
plot_weight_sum(result20.list$M2, assets20$lB, assets20$uB)
dev.off()
############################################################################
# (2) purgeChull/ purgeSlope(best) / purgeChull
# compare purgeExcess(Ver 1.2), purgeChull(Ver 3) & purgeSlope(Ver 4)
# test using results from Ver 2
ind20 <- testPurgeChull(result20.list$M2, assets20$mu, assets20$covar) #chull??
#return ind kept

# visualization
plot_EFpurge(result20.list$M2, assets20$mu, assets20$covar)
plot_EFpurge(result50.list$M5, assets50$mu, assets50$covar)

# when weights sum to 1, EF is convex naturally!
plot_EFpurge(result50.list$M3, assets50$mu, assets50$covar) 

pdf("D:/Master Thesis/MyThesis/Pictures/purgeEF_20.pdf",
    width = 10, height = 7) 
plot_EFpurge(result20.list$M2, assets20$mu, assets20$covar)
dev.off()

#############################################################################
# (3) solve() from Ver 2 and chol() from Ver 1.2
# compare time cost on ind.company
testInv <- function(result, mu, covar){
  free_indices <- result$free_indices
  weights_set <- result$weights_set
  n <- ncol(result$weights_set)
  inv_covarF <- function(col, inv){
    w <- weights_set[, col]
    f <- free_indices[[col]]
    get <- Env3$getMatrices(mu, covar, w, f)
    covarF <- get$covarF
    covarFB <- get$covarFB
    muF <- get$muF
    wB <- get$wB
    if(inv == 1) chol2inv(chol(covarF)) %*% cbind(1, muF, covarFB %*% wB)
    else if(inv == 2) solve(covarF) %*% cbind(1, muF, covarFB %*% wB)
    else if(inv == 3) solve(covarF, cbind(1, muF, covarFB %*% wB))
  }
  micro <- microbenchmark(inv1 = inv1 <- sapply(1:(n-1), function(col) inv_covarF(col, 1)),
                          inv2 = inv2 <- sapply(1:(n-1), function(col) inv_covarF(col, 2)),
                          inv3 = inv3 <- sapply(1:(n-1), function(col) inv_covarF(col, 3)))
  is.allequal <- all.equal(inv1, inv3) & all.equal(inv2, inv3)
  list(micro = micro, is.allequal = is.allequal)
}

testInv(result20.list$M2, assets20$mu, assets20$covar)
testInv(result50.list$M2, assets50$mu, assets50$covar)

# matrix quality of covarF ...plot....
#############################################################################







addW(r3$weights_set)

adw<-addW(r3$weights_set_purge)$weights_set_new
adwn <- adw[,purgeChull(adw, mu, covar)]

rr <- lapply(1:ncol(adwn), function(x)(
  which( !(abs(adwn[,x]-1e-8)< 1e-10| abs(adwn[,x]- 0.075)<1e-10))
))

dif <- sapply(1:(ncol(adwn)-1), function(x) 
  all.equal(rr[[x+1]],rr[[x]])==TRUE)
dif
which(dif) # 4 7 10 13
h <- c()
for(j in which(dif)){
  ms <- MS(adwn[,(j-1):(j+2)], mu, covar)
  # test jth
  h1 <- hyperbolic(mu_in = ms[2,3], adwn[,j-1],adwn[,j+1], mu, covar  )-ms[2,2]# >0
  h2 <- hyperbolic(mu_in = ms[3,3], adwn[,j],adwn[,j+2], mu, covar  )-ms[3,2] # >0
  h <- c(h,h1,h2)
}

j-1
j #same
j+1 #same
j+2 


