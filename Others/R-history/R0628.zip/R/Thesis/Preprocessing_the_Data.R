# company asset data
pdf("D:/Master Thesis/MyThesis/Pictures/company.pdf",
    width = 8, height = 5) 
plot(sqrt(diag(assets1457$covar)), assets1457$mu, pch = 16, cex = 0.4,
     xlab = expression(sigma), ylab = expression(mu), 
     main = "Company Assets")
dev.off()

# SP500
sp <- transIndex(SP500)
pdf("D:/Master Thesis/MyThesis/Pictures/sp500.pdf",
    width = 8, height = 5)
plot(sqrt(diag(sp$covar)), sp$mu, pch = 16, cex = 0.4,
     xlab = expression(sigma), ylab = expression(mu), 
     main = "SP500")
dev.off()

# NASDAQ
nasdaq <- transIndex(NASDAQ)
i <- which.max(nasdaq$mu) #remove the outlier for better ploting..
pdf("D:/Master Thesis/MyThesis/Pictures/nasdaq.pdf",
    width = 8, height = 5) 
plot(sqrt(diag(nasdaq$covar))[-i], nasdaq$mu[-i], pch = 16, cex = 0.4,
     xlab = expression(sigma), ylab = expression(mu), 
     main = "NASDAQ")
dev.off()



