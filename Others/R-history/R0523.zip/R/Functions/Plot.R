MS <- function(solution_set, mu, covar){
  Sig2 <- colSums(solution_set *(covar %*% solution_set) )
  Sig <- sqrt(Sig2)
  Mu <- t(solution_set) %*% mu
  cbind(Sig = Sig, Sig2 = Sig2, Mu = Mu)
}

MS_plot <- function(solution_set, mu, covar){  #list of solution_set, legend...
  Sig2 <- MS(solution_set, mu, covar)[,"Sig2"]
  Mu <- MS(solution_set, mu, covar)[,"Mu"]
  plot(Sig2, Mu, type = "o", pch = 16, col = "blue",
       main = "Efficient Frontier", xlab = expression(mu),
       ylab = expression(sigma^2))
}

MS_points <- function(solution_set, mu, covar, col = "red"){  #list of solution_set, legend...
  Sig2 <- MS(solution_set, mu, covar)[,"Sig2"]
  Mu <- MS(solution_set, mu, covar)[,"Mu"]
  points(Sig2, Mu, pch = 16, col = col)
}

Wcompare <- function(mu, covar, lB, uB){  #as.matrix(lB or uB)!
  w.cla <- CLA$M3(mu, covar, lB, uB)$weights_set_purge
  
  n <- ncol(w.cla) 
  # rescale density, for better plotting...
  lam <- ((0:n)/n)^2
  s<- lapply(lam, function(x) 
    return(tryCatch(QP.solve(mu, covar, lB, uB,x),  # skip error, pick "correct" mu
                    error=function(e) NULL)))
  ind.qp <- which(!sapply(s,is.null))
  w.qp <- sapply(ind.qp, function(x) s[[x]]) # remove NULL terms

  given.risk <- MS(w.cla, mu, covar)[,"Sig"]
  w.cccp <- sapply(given.risk, function(x) CCCP.solve (covar, mu, x,  
                                 lB, uB))
  w.cccp <- matrix(w.cccp[!is.na(w.cccp)], nrow = nrow(w.cccp))  # remove NaN
  
  micro <- microbenchmark( w.cla = CLA$M3(mu, covar, lB, uB)$weights_set_purge,
                           w.qp = lapply(((0:(n-1))/n)^2, function(x) 
                             return(tryCatch(QP.solve(mu, covar, lB, uB,x),  # skip error, pick "correct" mu
                                             error=function(e) NULL))),
                           w.cccp = sapply(given.risk, function(x) CCCP.solve (covar, mu, x,  
                                                                      lB, uB)),
                          times = 3)
  
  list(weights = list(w.cla = w.cla, w.qp = w.qp, w.cccp = w.cccp),
       micro = micro, lambda.qp = lam[eeind.qp]) # compare micro?
}

Total.plot <- function(w.list, mu, covar){
  MS_plot(w.list[[1]], mu, covar)
  for (i in 2:length(w.list)){
    MS_points(w.list[[i]], mu, covar)
  }
  legend("bottomright", 
         legend = names(w.list),
         lty = 1, col = c("blue",2:length(w.list)))
}

###########################################################################
CLA_results50 <- readRDS(d.file("CLA_results50.rds", exists = FALSE))
assets50 <- readRDS(d.file("assets50.rds", exists = FALSE))

weights.compare <- Wcompare(assets50$mu, assets50$covar, 
                         assets50$lB, as.matrix(rep(1,50)))

weights.micro <- weights.compare$micro
weights.list <- weights.compare$weights
# time: QP < CLA << CCCP

Total.plot(weights.list[c(2:3)], mu = assets50$mu, covar = assets50$covar)
# under a given risk, the expected return of the point on CLA EF are 
# generally slightly higher than expected return on quadratic EF.
# hard to observe on EF plot.

# Portgr returns positive weights (slightly) larger than lB or
# (slightly) smaller than uB, but not on the bounds
# Portgr requires given risks, hard to know the range of given risks
# CLA returns bounded weights exactly on uB or lB, but not work for small number of assets


