# 1) Portfolio optimization under a given risk--cccp package
#return risk, expected return and weights 
CCCP.solve <- function(covar, mu, given.risk, lB, uB){ 
  N <- nrow(covar)
  sqrt.cov <- sqrm(covar)
  ## Portfolio risk constraint, under a given risk
  soc1 <- socc(F = sqrt.cov, g = rep(0, N), d = rep(0, N), f = given.risk)
  ## non-negativity constraint
  nno1 <- nnoc(G =rbind(-diag(N),diag(N)), h = c(lB, uB))
  ## Budget constraint
  A1 <- matrix(rep(1, N), nrow = 1)
  b1 <- 1.0
  ## optimization
  ans <- cccp(q =as.vector(mu)*(-1), A = A1, b = b1, cList = list(nno1, soc1),  
              optctrl = ctrl(trace = FALSE)) # weights sum up to 1, under above constraints
  getx(ans)
}

# 2) Quadratic Programming -- quadprog package
# to minimize 0.5 sqrt(wt cov w)-lambda(w mu), solve w, lambda from 0 to 1-
QP.solve <- function(mu, covar, lB, uB, lambda){
  n <- nrow(mu)
  D <- covar 
  d <- mu 
  A <- cbind(-diag(n), diag(n), rep(1,n), rep(-1,n))
  b <- c(-uB, lB,1,-1) #uB; lB; sum up to 1
  solve.QP(D*(1-lambda),d* lambda,A,b)$solution
  
}

#eg.
w50.qp <- QP.solve(assets50$mu, assets50$covar, assets50$lB, assets50$uB,0.5)



  

