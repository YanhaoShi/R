if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
# Compare results

CLA_results <- function(m, re = 10){  # re: repeat times # m: first m assets
  assets <- readRDS(d.file(paste("assets", m, ".rds", sep = ""), exists = FALSE))
  micro <- microbenchmark(
    r1 <- CLA$M1(assets$mu, assets$covar, assets$lB, assets$uB),
    r2 <- CLA$M2(assets$mu, assets$covar, assets$lB, assets$uB),
    r3 <- CLA$M3(assets$mu, assets$covar, assets$lB, assets$uB), times = re) 
  t <- unname(sapply(levels(micro$expr), 
                     function(x){median(micro$time[micro$expr==x])*1e-6}))
  list(r1 = r1, r2 = r2, r3 = r3,  # cla.solver results
       t = t)  # times: millionseconds
}


#  save cla resulte(ver1, ver2, ver3) and cla time
if(file.exists(d.file("CLA_time.rds", exists = FALSE))){
  CLA_time <- readRDS(d.file("CLA_time.rds", exists = FALSE))
}else{
  CLA_time <- c()
}
for (m in 50:120){#
  if( !file.exists(d.file(paste("CLA_results", m, ".rds", sep = ""), exists = FALSE))){ 
  CLA_analysis<- CLA_results(m, re = 10)
  CLA_time <- rbind(CLA_time, CLA_analysis$t)
  saveRDS(CLA_analysis[1:3], d.file(paste("CLA_results", m, ".rds", sep = ""), 
                                    exists = FALSE))
  }
}
saveRDS(CLA_time, d.file("CLA_time.rds", exists = FALSE))
row.names(CLA_time) <- 50:120


sessionInfo() # computing info
#######################################################################################
plot(x = 50:120, y = CLA_time[,1], col = "black", type = "l", pch = 16, 
     ylim = range(CLA_time), main = "Efficient Frontier of different versions",
     xlab = "number of assets", ylab = "milliseconds")
points(50:120, CLA_time[,2], col = "red", type = "l", pch = 16)
points(50:120, CLA_time[,3], col = "blue", type = "l", pch = 16)
legend("topleft", legend = c("ver1", "ver2", "ver3"), 
       col = c("black", "red", "blue"), lty = 1)

png(d.file("CLA_time_plot.png", exists = FALSE))
dev.off()
#########################################

kappa(assets50$covar)
ev <- eigen(assets_50$covar, only.values=TRUE)$values
plot(ev, log="y") #not too bad

r3 <-as.matrix(r_50[[3]])
ef <- efFrontier1(assets_50$mu, assets_50$covar, as.matrix(r_50[[3]]), 10)
ef1 <- efFrontier1(assets_50$mu, assets_50$covar, r2_50$solution_set,10)




 
