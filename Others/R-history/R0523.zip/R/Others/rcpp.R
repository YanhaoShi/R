library(Rcpp)
library(microbenchmark)
cppFunction('int add(int x, int y, int z) {
  int sum = x + y + z;
            return sum;
            }')


add(1,2,3)
sum(1:3)
add.r <- function(x,y,z) x+y+z
microbenchmark(add(1,2,3), sum(c(1,2,3)), add.r(1,2,3))


cppFunction('int one(){
            return 1;
            }')
one()

# declare the type of each input in the same way we declare the 
# type of the output. 

sumR <- function(x) {
  total <- 0
  for (i in seq_along(x)) {
    total <- total + x[i]
  }
  total
}
#  the cost of loops is much lower in C++.
#  In C++, vector indices start at 0
cppFunction('double sumC(NumericVector x) {
  int n = x.size();
            double total = 0;
            for(int i = 0; i < n; ++i) {
            total += x[i];
            }
            return total;
            }')

x <- runif(1e3)
microbenchmark(
  sum(x),
  sumC(x),
  sumR(x)
)
all.equal(sumR(x), sumC(x))









