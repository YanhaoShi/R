# Compare results

# compare 3 versions of CLA time and results
CLA_results <- function(ind, re = 10){  # re: repeat times # m: first m assets
  assets1457 <- readRDS(d.file("assets1457.rds", exists = FALSE))
  assets <- GetAssets(ind, assets1457)
  micro <- microbenchmark(
    r1 <- CLA$M1(assets$mu, assets$covar, assets$lB, assets$uB),
    r2 <- CLA$M2(assets$mu, assets$covar, assets$lB, assets$uB),
    times = re) 
  t <- unname(sapply(levels(micro$expr), 
                     function(x){median(micro$time[micro$expr==x])*1e-6}))
  list(r1 = r1, r2 = r2,  # cla.solver results
       t = t)  # times: millionseconds
}


# x-axis scaled index
exp_ind <- function(x, start, end){
  a <- ceiling(log(start)/log(x) )
  b <- floor(log(end)/log(x))
  list(power = a:b, ind = round(x^(a:b)))
}


# cla vs. qp
w.compare2 <- function(mu, covar, lB, uB){  #as.matrix(lB or uB)!
  result.cla <- CLA$M2(mu, covar, lB, uB)
  w.cla <- result.cla$weights_set_purge
  n <- ncol(w.cla)  # rescale density, for better plotting...
  lam <- ((0:n)/n)^2
  micro <- microbenchmark( cla = CLA$M2(mu, covar, lB, uB),
                           qp = w.qp <- lapply(lam,function(x) 
                             return(tryCatch(QP.solve(mu, covar, lB, uB,x), # skip error, pick "correct" mu
                                             error=function(e) NULL))),
                           times = 1)
  ind.qp <- which(!sapply(w.qp,is.null))
  w.qp <- sapply(ind.qp, function(x) w.qp[[x]]) # remove NULL terms
  
  list(weights = list(w.cla = w.cla, w.qp = w.qp),
       MS = list( ms.cla = MS(w.cla, mu, covar),
                  ms.qp = MS(w.qp, mu, covar)),
       micro = micro, lambda.qp = lam[ind.qp], result.cla = result.cla)# compare micro?
}

# cla, qp vs. cccp
w.compare3 <- function(mu, covar, lB, uB){  #as.matrix(lB or uB)!
  w.cla <- CLA$M3(mu, covar, lB, uB)$weights_set_purge
  n <- ncol(w.cla)  # rescale density, for better plotting...
  micro <- microbenchmark( cla = result.cla <- CLA$M3(mu, covar, lB, uB),
                           qp = w.qp <- lapply(((0:n)/n)^2, 
                                               function(x) return(tryCatch(QP.solve(mu, covar, lB, uB,x), # skip error, pick "correct" mu
                                                                           error=function(e) NULL))),
                           cccp = w.cccp <- sapply(MS(w.cla, mu, covar)[,"Sig"], 
                                                   function(x) CCCP.solve (covar, mu, x, lB, uB)),
                           times = 3)
  
  
  lam <- ((0:n)/n)^2
  ind.qp <- which(!sapply(w.qp,is.null))
  w.qp <- sapply(ind.qp, function(x) w.qp[[x]]) # remove NULL terms
  w.cccp <- matrix(w.cccp[!is.na(w.cccp)], nrow = nrow(w.cccp))  # remove NaN
  
  list(weights = list(w.cla = w.cla, w.qp = w.qp, w.cccp = w.cccp),
       MS = list( ms.cla = MS(w.cla, mu, covar),
                  ms.qp = MS(w.qp, mu, covar),
                  ms.cccp = MS(w.cccp, mu, covar)),
       micro = micro, lambda.qp = lam[ind.qp], result.cla = result.cla)# compare micro?
}