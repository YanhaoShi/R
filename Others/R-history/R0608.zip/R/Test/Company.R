if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
assets1457




## corresponding index for company assets, each for 50 times
if(!file.exists(d.file("ind_company.rds", exists = FALSE))){
  ee <- exp_ind(1.2, 50, 1457) #at least 50 assets, at most 1457 assets, index power of 1.2
  # if 1.1, too much to plot and compute; if 1.3 or larger, too little information.
  set.seed(2017)
  ind.company <- list()
  for(i in 1:length(ee$power)){
    ind.company[[i]] <- lapply(rep(ee$ind[i], 50), function(x) sample(seq(1457), x, replace = FALSE))
  }
  saveRDS(ind.company, d.file("ind_company.rds", exists = FALSE))
}

ind.company <- readRDS(d.file("ind_company.rds", exists = FALSE))
l.company <- length(ind.company)
n.company <- 1457
label.company <- exp_ind(1.2, 50, n.company)$ind

## data and result set
for(i in 1:length(ind.company)){#length(ind.company)
  for(j in 1:10){
    if( !file.exists(d.file(paste("Company", i, "_set", j, sep = ""), exists = FALSE))){ 
      ind <- ind.company[[i]][[j]]
      assets <- GetAssets(ind, assets1457)
      weights.compare <- w.compare3(assets$mu, assets$covar, 
                                   assets$lB, assets$uB)
      saveRDS(assets, d.file(paste("Company", length(ind.company[[i]][[1]]), "_data", j, sep = ""), exists = FALSE))
      saveRDS(weights.compare, d.file(paste("Company", length(ind.company[[i]][[1]]), "_set", j, sep = ""), exists = FALSE)) 
      #eg. Company55_data1: 55 assets in total, with 1th indices set
      #    Company55_set1: the result of Company55_data1  
    }
  }
}


##draft
for(i in 1:11){  ##change to 12-18
  for(j in 1:10){
    nas <- readRDS(d.file(paste("Company", length(ind.company[[i]][[1]]), "_set", j, sep = ""),exists = F))
    saveRDS(nas, d.file(paste("Company", length(ind.company[[i]][[1]]), "_set", j, ".rds", sep = ""),exists = F))
  }
}
l.company = 11
label.company <- label.company[1:11]
###

# analysis_company: 
if(!file.exists(d.file("analysis_company.rds"))){ 
  cla.company <- list()
  t_compare.company <- list()
  nweights.company <- matrix(0, ncol = l.company, nrow = 10)
  nweights.company_unpurge <- matrix(0, ncol = l.company, nrow = 10)
  covF.kappa.company <- matrix(0, ncol = l.company, nrow = 10)
  covF.rcond.company <- matrix(0, ncol = l.company, nrow = 10)
  cov.check.company <- matrix(0, ncol = l.company, nrow = 10)
  covF.company <- list() # 8 sub-list, each with 10 sub-list, with cla-result of covFs
  lambda.company <- list()
  for(i in 1:l.company){
    re <- lapply(1:10, function(x)
      readRDS(d.file(paste("Company", length(ind.company[[i]][[1]]), "_set", x, ".rds", sep = ""), 
                     exists = FALSE)))
    
    
    cla.company[[i]] <- lapply(1:10, function(x)re[[x]]$result.cla)
    lambda.company[[i]] <- lapply(1:10, function(x)re[[x]]$lambda.qp)
    t_compare.company[[i]] <- sapply(1:10, function(x) {micro <- re[[x]]$micro
    unname(sapply(levels(micro$expr), 
                  function(y){median(micro$time[micro$expr==y])*1e-6}))}) 
    #take the median, miliseconds 
    
    nweights.company[, i] <- sapply(1:10, function(x) ncol(cla.company[[i]][[x]]$weights_set_purge))
    nweights.company_unpurge[,i] <- sapply(1:10, function(x) ncol(cla.company[[i]][[x]]$weights_set))
    
    covF.company[[i]] <- lapply(1:10, function(x) lapply(cla.company[[i]][[x]]$covarF, as.matrix))
    covF.kappa.company[, i] <- sapply(1:10,function(x) max(sapply(covF.company[[i]][[x]], kappa)))
    covF.rcond.company[, i] <- sapply(1:10,function(x) min(sapply(covF.company[[i]][[x]], rcond)))
    cov.check.company[, i] <- sapply(1:10, function(x) is.positive.definite(readRDS(d.file(
      paste("Company", length(ind.company[[i]][[x]]), "_data", 1, ".rds", sep = ""), 
      exists = FALSE))$covar) )
  }
  colnames(nweights.company) <- label.company
  colnames(nweights.company_unpurge) <- label.company
  colnames(cov.check.company) <- label.company
  colnames(covF.kappa.company) <- label.company
  colnames(covF.rcond.company) <- label.company
  analysis.company <- list(cla_result = cla.company,
                      t_compare = t_compare.company,
                      nweights = nweights.company,
                      nweights_unpurge = nweights.company_unpurge,
                      covF.kappa = covF.kappa.company,
                      covF.rcond = covF.rcond.company,
                      covF = covF.company,
                      cov.check = cov.check.company,
                      lambda.QP = lambda.company)
  saveRDS(analysis.company, d.file("analysis_company.rds", exists = FALSE))
}
analysis.company <- readRDS(d.file("analysis_company.rds", exists = FALSE))

#######################################################################################
#Plotting
# nweights_ind_boxplot
boxplot(analysis.company$nweights, xlab = "Number of Assets", ylab = "Number", 
        main = "Number of Weights Sets", xaxt = "n")
axis(1, at = seq(l.company), labels = label.company )

# nweights_ind_plot
plot(apply(analysis.company$nweights, 2, mean), 
     ylim = range(c(analysis.company$nweights, analysis.company$nweights_unpurge)), 
     pch = 16, col = "red",
     xlab = "Number of Assets", ylab = "Number", type = "o",
     main = "Number of Weights Sets", xaxt = "n")
axis(1, at = seq(l.company), labels = label.company)
lapply(1:10, function(x) points(analysis.company$nweights[x,], pch = 16, 
                                col = adjustcolor("blue", 0.5)))
lapply(1:10, function(x) points(analysis.company$nweights_unpurge[x,], pch = 16, 
                                col = adjustcolor("yellow", 0.5)))
legend("topleft", legend = c("mean-purge", "purge", "unpurge"), 
       col = c("red", "blue", "yellow"), lwd = 1, pch =16)

# kappa
boxplot(analysis.company$covF.kappa, xlab = "Number of Assets", ylab = "kappa", 
        main = "Max-kappa of CovF", xaxt = "n")
axis(1, at = seq(l.company), labels = label.company)

# rcond
boxplot(analysis.company$covF.rcond, xlab = "Number of Assets", ylab = "rcond", 
        main = "Min-rcond of CovF", xaxt = "n")
axis(1, at = seq(l.company), labels = label.company)

# t_compare, mean
t_mean <- sapply(seq(l.company), function(x) apply(analysis.company$t_compare[[x]], 1, mean))
colnames(t_mean) <-  label.company
plot(rep(1, 30), as.vector(analysis.company$t_compare[[1]]), log = "y",
     col = rep(c(adjustcolor("red", 0.3), adjustcolor("blue", 0.3), 
                 adjustcolor("green", 0.3)), 10), 
     xlim = c(1, l.company), ylim = range(analysis.company$t_compare), xaxt = "n", pch = 16, 
     xlab = "Number of Assets", ylab = "milliseconds", main = "Time Comparison")
axis(1, at = seq(l.company), labels = label.company)
lapply(2:l.company, function(x) 
  points(rep(x, 30), as.vector(analysis.company$t_compare[[x]]), pch = 16,
         col = rep(c(adjustcolor("red", 0.3), adjustcolor("blue", 0.3), 
                     adjustcolor("green", 0.3)), 10)))
lines(t_mean[1,], col = "red")
lines(t_mean[2,], col = "blue")
lines(t_mean[3,], col = "green")
legend("topleft", legend = c("cla", "qp", "cccp"), col = c("red", "blue", "green"), 
       pch = 16)



# t_compare_cla_qp
plot(seq(l.company), t_mean[1,], type = "o", ylim = range(t_mean[-3,]), col = "red", 
     pch = 16, xaxt = "n", xlab = "Number of Assets", log = "y",
     ylab = "milliseconds", main = "Time Comparison of CLA and QP")
lines(seq(l.company), t_mean[2,], col = "blue", pch = 16, type = "o")
axis(1, at = seq(l.company),labels = label.company)
legend("topleft", legend = c("cla", "qp"), col = c("red", "blue"), lwd = 1, pch = 16)

# qp method is faster than cla when the number of assets is small, (55-95)
# but much slower when number of assets is larger (114-410)


## draft here

m <- covF[[2]][[1]][[22]]
kappa(m)

rcond(m)
plot(cov.kappa, type = "o", main = "kappa")

cov.m <- lapply(cf, as.matrix)
sapply(m, rcond)
lapply(cov.m, nearPD)

grid::grid.raster(readPNG(d.file("company_nweights.png", exists = F)))
grid::grid.raster(readPNG(d.file("company_nweights_plot.png", exists = F)))
grid::grid.raster(readPNG(d.file("company_kappa.png", exists = F)))
grid::grid.raster(readPNG(d.file("company_rcond.png", exists = F)))
grid::grid.raster(readPNG(d.file("company_t_compare.png", exists = F)))

