if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
r_50_unpurge <- cla.solver.remove(assets[[50]]$mu, assets[[50]]$covar, 
                                    assets[[50]]$lB, assets[[50]]$uB)

r2_50 <- cla.solver2(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)
r2_50_purge <- r2_50[1:4]
r2_50_unpurge <- r2_50[5:8]

all.equal(r_50_unpurge, r2_50_unpurge, check.attributes = F)
# unequal, because the improvements of function computeLambda, computeW...


# purgeNummErr1 and purgeNummErr2 get same results
index1 <- purgeNummErr1(assets[[50]]$lB, assets[[50]]$uB, 
                        as.data.frame(r2_50_unpurge$weights_set), 1e-9, 1e-10)

index2 <- purgeNummErr2(assets[[50]]$lB, assets[[50]]$uB,
                        as.data.frame(r2_50_unpurge$weights_set), 1e-9, 1e-10)

pur1 <- list( r2_50_unpurge$weights_set[, -index1], r2_50_unpurge$free_indices[-index1],
              r2_50_unpurge$lambdas[-index1], r2_50_unpurge$gammas[-index1])

pur2 <- list(r2_50_unpurge$weights_set[, index2], r2_50_unpurge$free_indices[index2],
             r2_50_unpurge$lambdas[index2], r2_50_unpurge$gammas[index2])

all.equal(pur1, pur2)

# purgeExcess1 and purggExcess2 get same results
index3 <- purgeExcess1(assets[[50]]$mu, r2_50_unpurge$weights_set, 1e-10)
index4 <- purgeExcess2(assets[[50]]$mu, r2_50_unpurge$weights_set, 1e-10)
pur3 <- list( r2_50_unpurge$weights_set[, -index3], r2_50_unpurge$free_indices[-index3],
              r2_50_unpurge$lambdas[-index3], r2_50_unpurge$gammas[-index3])

pur4 <- list(r2_50_unpurge$weights_set[, index4], r2_50_unpurge$free_indices[index4],
             r2_50_unpurge$lambdas[index4], r2_50_unpurge$gammas[index4])

all.equal(pur3[[4]], pur4[[4]])


# compare purgeExcess and purgeExcess1
purgeExcess(t(assets[[50]]$mu), r2_50_unpurge$lambdas, r2_50_unpurge$gammas, 
            r2_50_unpurge$free_indices, r2_50_unpurge$weights_set)



plot_ms <- function(x,y, emph) {
  plot(x, y,      col = 2-emph, type="c", xlab = quote(sigma),ylab = quote(mu) ) # graph
  text(x, y, 1:n, col = 2-emph, cex = .75 ) 
  ch <- chull(y, x)
  ch <- sort(ch)[sort(ch) >= which.max(y)] #remove points on left side of highest return point
  # str(ch)
  lines(x[ch], y[ch], lwd =2 , col=adjustcolor("blue",.5))
}
  
purgeExcess3 <- function(mean, covar, solution_set, tol){ 
  n <- ncol(solution_set)
  mu <- t(mean) %*% solution_set 
  cov <- diag(t(solution_set) %*% covar %*% solution_set)####inefficient
  mu.linear <- mu
  for(i in 2:(n-1)){
    mu.linear[i] <- (cov[i] - cov[i+1])/(cov[i-1] - cov[i+1])*(mu[i-1] - mu[i+1]) + mu[i+1]
  }
  wrong <-  mu - mu.linear > -tol
  plot_ms(cov, mu, emph= 2-wrong)
  wrong
}

colSums(r2_50_unpurge$weights_set)
purgeExcess3(assets[[50]]$mu, assets[[50]]$covar, r2_50_unpurge$weights_set, 1e-10)

mu.50 <- t(assets[[50]]$mu) %*% r2_50_unpurge$weights_set
cov.50 <- diag(t(r2_50_unpurge$weights_set) %*% assets[[50]]$covar %*% r2_50_unpurge$weights_set)
plot(cov.50, mu.50, col = 2-index4)
