if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
pu <- purge(assets_50$mu, assets_50$lB, assets_50$uB, r2_50_unpurge$solution_set, 
              1e-9, 1e-10, 1e-12) 
purgePU <- list(r2_50_unpurge$solution_set[,-pu$i], 
                r2_50_unpurge$free_indices[-pu$i], 
                r2_50_unpurge$gammas[-pu$i],
                r2_50_unpurge$lambdas[-pu$i]  )
all.equal(r2_50_purge, purgePU, check.names = FALSE)




purge <- function(mean, lB, uB, solution_set, 
                  tol.s, tol.b, tol){ 
  n <- ncol(solution_set)
  i.s <- which(abs(colSums(solution_set)-1) > tol.s)
  m_lB <- matrix(rep(lB, n), ncol = n)
  m_uB <- matrix(rep(uB, n), ncol = n) 
  m_logical <- (solution_set - m_lB < -tol.b) | (solution_set - m_uB > tol.b)
  i.b <- which(apply(m_logical, 2, any))
  i.un <- c(i.s, i.b, n+1)
  
  solution_set <- solution_set[,-i.un]
  n <- ncol(solution_set)
  mu <- t(mean) %*% solution_set
  i.ex <- which( (mu[2:(n-1)] - mu[3:n]) < -tol )
  list(i.un = i.un, i.ex = i.ex, i = c(i.un, i.ex))
} 

pu$i
pu$i.ex
(1:41)[-pu$i][30]

g <- function(n, i, k){
  a <- (1:n)[-i][-k]
   b <-   c(  i, (1:n)[-i][k])
   list(a,b)
}
g(15, c(2,3,5,8,13,14), C(2,4,6))

