if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
index.df # brief infomation of FRAPO index

#for example
fitting.plot(SP500, 21) #weekly observations
fitting.plot(ESCBFX, 3) #daily observations
fitting.plot(NASDAQ, 10) #weekly observations


fitting.plot(StockIndexAdj,1)# weekly: HYP best; (Company dataset: weekly)
fitting.plot(StockIndexAdjD,1)# daily: GHD best

##########################################################################################
rzoo <- SP500[,1:20]

Nassets <- ncol(rzoo)  
Nobs <- nrow(rzoo)
mu <- colMeans(rzoo)
S <- cov(rzoo)
SR <- sqrm(S) # square root of a matrix
delta <- sqrt(qchisq(0.9, Nassets)) # 90% quantile for the returns uncertainties, under ND
## Determining feasible risk aversion
SigMax <- max(colSds(rzoo))
SigMin <- min(colSds(rzoo))
#in case of overfitting
ra <- seq(SigMin * 1.1, SigMax * 0.9, length.out = 20) / SigMax 
SigSeq <- SigMin/ra


##list of risks, outlier removed and rescaled

## classical mean-variance(MV) and robust counterpart(RC) results
MV <- sapply(SigSeq, function(x) c(Porgr(SR, mu, x)$risk, Porgr(SR, mu, x)$mean))
rownames(MV) <- c("risk", "mean")


theta <- ra + (1 - ra) * delta / sqrt(Nobs) 
Robust_MV <- sapply(theta, function(x)c(Porgr(SR, mu, SigMin/x)$risk, Porgr(SR, mu, SigMin/x)$mean) )
rownames(Robust_MV) <- c("risk", "mean")

## replace theta by lambda
theta2lambda <- function(theta, Nassets, Nobs, level){
  delta <- sqrt(qchisq(level, Nassets))
  lambda <- theta / (1 + theta * (delta / sqrt(Nobs)))
  lambda
}
## robust allocation and equivalent mean-variance allocation, eg. theta = 0.7


theta0 <- 0.7 
MV0 <- c(Porgr(SR, mu, SigMin / theta0)$risk, Porgr(SR, mu, SigMin / theta0)$mean)

lam <- theta2lambda(theta0, Nassets = Nassets, Nobs = Nobs, level = 0.9)
Robust_MV0 <- c(Porgr(SR, mu = mu, SigMin / lam)$risk, Porgr(SR, mu = mu, SigMin / lam)$mean)

## plotting efficient frontier 
plot(MV["risk", ], MV["mean", ], type = "o",
     xlim = range(MV["risk", ], Robust_MV["risk", ]), 
     ylim = range(MV["mean", ], Robust_MV["mean", ]),
     xlab = expression(sigma), ylab = expression(mu), pch =16, col = "blue")
points(Robust_MV["risk", ], Robust_MV["mean", ], col = "red", pch = 19)

## Superimposing equivalence points
points(MV0[1], MV0[2], col = "green",  pch = 16)
points(Robust_MV0[1], Robust_MV0[2], col = "darkgreen", pch = 16)
## Legend
legend("bottomright", legend = c("EF", "MV", "Robusts MV",
                             expression(paste("Robust MV: ", theta == 0.7)),
                             "Equivalent MV"),
       lty = c(1, NA, NA, NA, NA), pch = c(NA, 16, 16, 16, 16),
       col = c("blue", "blue", "red", "darkgreen", "green"))


#CLA$M3$cla.solver(assets[[50]]$mu, assets[[50]]$covar,
#                         assets[[50]]$lB, assets[[50]]$uB)

#non-negative weights, previous unpurged version
w <- as.matrix(cla.solver.remove(assets[[50]]$mu, assets[[50]]$covar, 
                       as.matrix(rep(0,50)), as.matrix(rep(1,50)))[[3]])
#bounded weights, previous unpurged version
w1 <- as.matrix(cla.solver.remove(assets[[50]]$mu, assets[[50]]$covar, 
                                 assets[[50]]$lB, assets[[50]]$uB)[[3]])
#bounded weights, unpurged version 
w2 <- as.matrix(cla.solver2(assets[[50]]$mu, assets[[50]]$covar, 
                                  assets[[50]]$lB, assets[[50]]$uB)$weights_set)
sig50 <- sqrm(assets[[50]]$covar)
mu50 <- assets[[50]]$mu
Mu50 <-  t(mu50) %*% w
SigSeq50 <- sqrt(diag(t(w) %*% assets[[50]]$covar %*% w))

MV <- sapply(sqrt(diag(t(w2) %*% assets[[50]]$covar %*% w2)), 
             function(x) c(Porgr(sig50, as.vector(mu50), x)$risk, 
                                     Porgr(sig50, as.vector(mu50), x)$mean))
MV 

plot(MV[1, ], MV[2, ], type = "o", pch =16, col = "blue", 
     xlab = expression(sigma), ylab = expression(mu), 
     ylim = range(MV[2,],Mu50), xlim = range(MV[1,], SigSeq50))

points(sqrt(diag(t(w) %*% assets[[50]]$covar %*% w)), 
       t(mu50) %*% w, col = "orange")

MV2 <- rbind(sqrt(diag(t(w2) %*% assets[[50]]$covar %*% w2)),
             t(mu50) %*% w2)
ch <- chull(t(MV2))
points(MV2[1,],MV2[2,], col = "red", type = "o", pch = 16)
points(MV2[1,ch],MV2[2,ch], col = "purple", type = "o", pch = 16)


points(sqrt(diag(t(w1) %*% assets[[50]]$covar %*% w1)),
       t(mu50) %*% w1, col = "green")

legend("bottomright", 
       legend = c("MV", "cla0 non-negative", "cla bounded", "cla0 bounded", "cla chull"),
       lty = 1, col = c("blue", "orange", "red", "green", "purple"))



