if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
index.df # brief infomation of FRAPO index

#for example
fitting.plot(SP500, 21) #weekly observations
fitting.plot(ESCBFX, 3) #daily observations
fitting.plot(NASDAQ, 10) #weekly observations


fitting.plot(StockIndexAdj,1)# weekly: HYP best; (Company dataset: weekly)
fitting.plot(StockIndexAdjD,1)# daily: GHD best

##########################################################################################
ind <- SP500[,1:20]  # define a index

Nassets <- ncol(ind)  
Nobs <- nrow(ind)
mu <- colMeans(ind)
S <- cov(ind)
SR <- sqrm(S) # square root of a matrix
delta <- sqrt(qchisq(0.9, Nassets)) # 90% quantile for the returns uncertainties, under ND
## Determining feasible risk aversion
SigMax <- max(colSds(ind))
SigMin <- min(colSds(ind))
#in case of overfitting
ra <- seq(SigMin * 1.1, SigMax * 0.9, length.out = 20) / SigMax 
SigSeq <- SigMin/ra


##list of risks, outlier removed and rescaled

## classical mean-variance(MV) and robust counterpart(RC) results
MV <- sapply(SigSeq, function(x) c(Porgr(SR, mu, x)$risk, Porgr(SR, mu, x)$mean))
rownames(MV) <- c("risk", "mean")


theta <- ra + (1 - ra) * delta / sqrt(Nobs) 
Robust_MV <- sapply(theta, function(x)c(Porgr(SR, mu, SigMin/x)$risk, Porgr(SR, mu, SigMin/x)$mean) )
rownames(Robust_MV) <- c("risk", "mean")

## replace theta by lambda
theta2lambda <- function(theta, Nassets, Nobs, level){
  delta <- sqrt(qchisq(level, Nassets))
  lambda <- theta / (1 + theta * (delta / sqrt(Nobs)))
  lambda
}
## robust allocation and equivalent mean-variance allocation, eg. theta = 0.7


theta0 <- 0.7 
MV0 <- c(Porgr(SR, mu, SigMin / theta0)$risk, Porgr(SR, mu, SigMin / theta0)$mean)

lam <- theta2lambda(theta0, Nassets = Nassets, Nobs = Nobs, level = 0.9)
Robust_MV0 <- c(Porgr(SR, mu = mu, SigMin / lam)$risk, Porgr(SR, mu = mu, SigMin / lam)$mean)

## plotting efficient frontier 
plot(MV["risk", ], MV["mean", ], type = "o",
     xlim = range(MV["risk", ], Robust_MV["risk", ]), 
     ylim = range(MV["mean", ], Robust_MV["mean", ]),
     xlab = expression(sigma), ylab = expression(mu), pch =16, col = "blue")
points(Robust_MV["risk", ], Robust_MV["mean", ], col = "red", pch = 19)

## Superimposing equivalence points
points(MV0[1], MV0[2], col = "green",  pch = 16)
points(Robust_MV0[1], Robust_MV0[2], col = "darkgreen", pch = 16)
## Legend
legend("bottomright", legend = c("EF", "MV", "Robusts MV",
                             expression(paste("Robust MV: ", theta == 0.7)),
                             "Equivalent MV"),
       lty = c(1, NA, NA, NA, NA), pch = c(NA, 16, 16, 16, 16),
       col = c("blue", "blue", "red", "darkgreen", "green"))


source("Functions/Ver1_previous.R")
#previous unpurged version, w>0
wp <- as.matrix(Method1$cla.solver.remove(assets[[50]]$mu, assets[[50]]$covar, 
                       as.matrix(rep(0,50)), as.matrix(rep(1,50)))[[3]])

#previous unpurged version, 1e-8 < w < 0.075
wplu <- as.matrix(Method1$cla.solver.remove(assets[[50]]$mu, assets[[50]]$covar, 
                                 assets[[50]]$lB, assets[[50]]$uB)[[3]])

source("Functions/Ver3.R")
#my unpurged version, 1e-8 < w < 0.075 
wmlu <- as.matrix(Method3$cla.solver(assets[[50]]$mu, assets[[50]]$covar, 
                                  assets[[50]]$lB, assets[[50]]$uB)$weights_set)
#my unpurged version, 1e-8 < w  
wml <- as.matrix(Method3$cla.solver(assets[[50]]$mu, assets[[50]]$covar, 
                            assets[[50]]$lB, as.matrix(rep(1,50)))$weights_set)

sig50 <- sqrm(assets[[50]]$covar)
isSymmetric(sig50)

mu50 <- assets[[50]]$mu
#Mu50 <-  t(mu50) %*% w
#SigSeq50 <- sqrt(diag(t(w) %*% assets[[50]]$covar %*% w))


wq <- sapply(sqrt(diag(t(wmlu) %*% assets[[50]]$covar %*% wmlu)),
             function(x) Porgr(sig50, as.vector(mu50), x)$weight)
colSums(wq) # good, always 1
# all weights are non-negative, not practical

MS <- sapply(sqrt(diag(t(wmlu) %*% assets[[50]]$covar %*% wmlu)), 
             function(x) c(Porgr(sig50, as.vector(mu50), x)$risk, 
                                     Porgr(sig50, as.vector(mu50), x)$mean))
rownames(MS)<- c("risk","return")
###
MS.mlu <- rbind(sqrt(diag(t(wmlu) %*% assets[[50]]$covar %*% wmlu)),
             t(mu50) %*% wmlu)
ch <- chull(t(MS.mlu))

MS.plu <- rbind(sqrt(diag(t(wplu) %*% assets[[50]]$covar %*% wplu)),
                t(mu50) %*% wplu)

MS.ml <- rbind(sqrt(diag(t(wml) %*% assets[[50]]$covar %*% wml)),
                t(mu50) %*% wml)

MS.p <- rbind(sqrt(diag(t(wp) %*% assets[[50]]$covar %*% wp)),
               t(mu50) %*% wp)

plot(MS["risk", ], MS["return", ], type = "o", pch =16, col = "blue", 
     xlab = expression(sigma), ylab = expression(mu), 
     xlim = range(cbind(MS, MS.mlu, MS.plu, MS.ml, MS.p)[1,]), 
     ylim = range(cbind(MS, MS.mlu, MS.plu, MS.ml, MS.p)[2,]))

points(MS.p[1,], MS.p[2,], col = "orange", pch = 16)
points(MS.mlu[1,], MS.mlu[2,], col = "red", type = "o")
points(MS.mlu[1,ch], MS.mlu[2,ch], col = "purple", type = "o", pch = 16) # convex
points(MS.plu[1,], MS.plu[2,], col = "green")
points(MS.ml[1,], MS.ml[2,], col = "yellow", pch=16)

legend("bottomright", 
       legend = c("MV", "cla-p", "cla-mlu", "cla-plu", "cla-mlu-chull", "cla-ml"),
       lty = 1, col = c("blue", "orange", "red", "green", "purple", "yellow"))

#the weight set of highest expected return, absolutely true?!
w.lu.max <- initAlgo(assets[[50]]$mu, assets[[50]]$lB, assets[[50]]$uB)$weights
points(sqrt(diag(t(w.lu.max) %*% assets[[50]]$covar %*% w.lu.max)),
       t(mu50) %*% w.lu.max, col = "black", pch = 16)


w.max <-initAlgo(assets[[50]]$mu, as.matrix(rep(0,50)), as.matrix(rep(1,50)))$weights
points(sqrt(diag(t(w.max) %*% assets[[50]]$covar %*% w.max)),
       t(mu50) %*% w.max, col = "black", pch = 16)

#analysis:
# 1) cla-plu and cla-mlu:
# previous version and my version come up with almost same weights set (almost same on the graph).
# the little differences might be caused by improvement of matrix inverse 
# (computeLambda and computeW)

# 2) cla-p much better than MV
# the weights of MV are non-negative, which is unnormal

# 3) cla-p and cla-ml:
# lower bounds make negligible difference (but upper bounds do: cla-ml vs cla-mlu)

# 4) MV
# part of MV efficient frontier






