cla.solver2 <- function(mean, covar,lB, uB){                                             
  # Compute the turning points,free sets and weights
  f <- initAlgo1(mean, lB, uB)$index
  w <- as.matrix(initAlgo1(mean, lB, uB)$weights)
  weights_set <- w # store solution
  lambdas <-  c()
  gammas <- c()
  free_indices <- list(f) ### 
  list_temp <- list() 
  while ( TRUE ) {
    # 1) case a): Bound one free weight 
    l_in <- 0
    temp_getMat1 <- getMatrices1(mean, covar,weights_set, f)
    covarF1 <- temp_getMat1$covarF
    covarFB1 <- temp_getMat1$covarFB
    meanF1 <- temp_getMat1$meanF
    wB1 <- temp_getMat1$wB
    
    if(length(f) > 1){  
      compl <- computeLambda3(covarFB1,meanF1,wB1,seq(length(f)),
                              list(lB = lB[f],uB = uB[f]),covarF1)
      lam <- compl$lambda
      bi <- compl$bi
      i_in <- ifelse(max(lam)>0, f[which.max(lam)], 0)
      l_in <- max(lam, 0) 
      bi_in <- ifelse(max(lam)>0, bi[which.max(lam)], 0)
    }  
    
    # 2) case b): Free one bounded weight
    l_out <- 0
    if(length(f) < length(mean)) {
      
      b <- (1:length(mean))[-f]
      for(i in b){
        
        temp_getMat2 <- getMatrices1(mean, covar, weights_set, c(f,i))
        covarF2 <- temp_getMat2$covarF
        covarFB2 <- temp_getMat2$covarFB
        meanF2 <- temp_getMat2$meanF
        wB2 <- temp_getMat2$wB
        temp_compLam <- computeLambda2(covarFB2,meanF2,wB2,length(meanF2),
                                       weights_set[i,ncol(weights_set)],covarF2)
        l2 <- temp_compLam$lambda 
        bi <- temp_compLam$bi
        
        if ((length(lambdas)==0 || l2<lambdas[length(lambdas)]) && (l2>l_out)){
          l_out <- l2
          i_out <- i
          temp_getMat_out <- temp_getMat2
        }
      }
    }
    
    if( (l_in <= 0) & (l_out <= 0) ) { # "stop" when at the min var solution! 
      
      # 3) compute minimum variance solution
      lambdas <- c(lambdas,0)
      meanF <- matrix(0,length(meanF))
      temp_compW <- computeW2(lambdas,covarFB1,meanF,wB1,covarF1)
      wF <- temp_compW$wF
      g <- temp_compW$gamma
      
      list_temp <- c(list_temp, list(covarF1))
      
      for(i in seq(length(f))){
        w[f[i]]=wF[i]
      }
      weights_set <- cbind(weights_set, w) # store solution
      gammas <- c(gammas, g)
      break
      
    } else {
      
      # 4) decide lambda       
      if(l_in>l_out){ 
        lambdas <- c(lambdas,l_in)
        f <- f[f != i_in] # remove i_in within f
        w[i_in] = bi_in # set value at the correct boundary
        temp_getMat1 <- getMatrices1(mean, covar,weights_set, f)
        covarF <- temp_getMat1$covarF
        covarFB <- temp_getMat1$covarFB
        meanF <- temp_getMat1$meanF
        wB <- temp_getMat1$wB
        temp_compW <- computeW2(lambdas,covarFB,meanF,wB,covarF)
        wF <- temp_compW$wF
        g <- temp_compW$gamma 
        list_temp <- c(list_temp, list(covarF))
        
      }else{
        lambdas <- c(lambdas,l_out)
        f <- c(f,i_out) # append i_out into f
        
        temp_getMat1 <- temp_getMat_out
        covarF <- temp_getMat1$covarF
        covarFB <- temp_getMat1$covarFB
        meanF <- temp_getMat1$meanF
        wB <- temp_getMat1$wB
        temp_compW <- computeW2(lambdas,covarFB,meanF,wB,covarF)
        wF <- temp_compW$wF
        g <- temp_compW$gamma
        list_temp <- c(list_temp, list(covarF))
      }
      
      
      for(i in seq(length(f))){
        w[f[i]]=wF[i]
      }
      
      weights_set <- cbind(weights_set, w) # store solution
      gammas <- c(gammas, g)
      free_indices <- c(free_indices, list(f))
      
    }
    
  } #end While  
  lambdas <- c(NA, lambdas) # The first step has no lambda or gamma, add NA instead.
  gammas <- c(NA, gammas)
  free_indices <- c(free_indices, NA) # The last step stop without weight set, add NA.
  
  # purge 
  i <- purgeNummErr2(lB, uB, weights_set, 1e-9, 1e-10) 
  weights_set_purge <- weights_set[,i]
  lambdas_purge <- lambdas[i]
  gammas_purge <- gammas[i]
  free_indices_purge <- free_indices[i]
  
  k <- purgeExcess1(mean, 
                    weights_set_purge, 1e-12)
  weights_set_purge <- weights_set_purge[,-k] 
  lambdas_purge <- lambdas_purge[-k] 
  gammas_purge <- gammas_purge[-k]
  free_indices_purge <- free_indices_purge[-k] 
  
  list(weights_set_purge = weights_set_purge, free_indices_purge = free_indices_purge, 
       gammas_purge = gammas_purge, lambdas_purge = lambdas_purge,
       weights_set = weights_set, free_indices=free_indices, 
       gammas = gammas, lambdas = lambdas, covarF = list_temp)
  
}