cla.solver.remove <- function(mean, covar, lB, uB)
{
  #initialize data.frames and vectors
  lambdas <- numeric(0) # lambdas 
  gammas <- numeric(0) # gammas
  free_weights <- data.frame() # free weights
  solution_set <- data.frame() # solution
  
  # Compute the turning points,free sets and weights
  temp_initAlgo <- initAlgo(mean, lB, uB)
  f <- temp_initAlgo[[1]]
  w <- temp_initAlgo[[2]]
  solution_set <- rbind(solution_set, w) # store solution
  lambdas <- append(lambdas, NA_integer_) 
  gammas <- append(gammas, NA_integer_) 
  free_weights <- as.data.frame(f)
  
  
  while ( TRUE ) {
    
    # 1) case a): Bound one free weight 
    l_in <- 0 
    if (length(f) > 1) {
      temp_getMat <- getMatrices(mean, covar,solution_set, f)
      covarF <- temp_getMat[[1]]; covarFB <- temp_getMat[[2]]; meanF <- temp_getMat[[3]]; wB <- temp_getMat[[4]]
      covarF_inv <- chol2inv(chol(covarF)) #solve(covarF)
      j <- 1
      for (i in f) {
        temp_compLam <- computeLambda(covarF_inv,covarFB,meanF,wB,j,as.list(c(lB[i],uB[i])))
        l <- temp_compLam[[1]]
        bi <- temp_compLam[[2]]
        if(l>l_in){  
          l_in <- l
          i_in <- i
          bi_in <- bi
        }
        j <- j + 1
      }
    }
    
    # 2) case b): Free one bounded weight
    l_out <- 0
    if(length(f) < length(mean)) {
      b <- getB(mean, f)
      for(i in b){
        temp_getMat <- getMatrices(mean, covar,solution_set,c(f,i))
        covarF <- temp_getMat[[1]]; covarFB <- temp_getMat[[2]]; meanF <- temp_getMat[[3]]; wB <- temp_getMat[[4]]
        covarF_inv <- chol2inv(chol(covarF)) #solve(covarF)
        temp_compLam <- computeLambda(covarF_inv,covarFB,meanF,wB,length(meanF),solution_set[,ncol(solution_set)][[i]])
        l <- temp_compLam[[1]]; bi <- temp_compLam[[2]]
        
        if ((is.na(lambdas[length(lambdas)]) || l<lambdas[length(lambdas)]) && (l>l_out)){
          l_out <- l
          i_out <- i
        }
      }
    }
    
    if( (l_in == 0 || l_in < 0) & (l_out == 0 || l_out < 0) ) { # "stop" when at the min var solution! 
      
      # 3) compute minimum variance solution
      lambdas <- append(lambdas,0)
      temp_getMat <- getMatrices(mean, covar,solution_set,f)
      covarF <- temp_getMat[[1]]; covarFB <- temp_getMat[[2]]; meanF <- temp_getMat[[3]]; wB <- temp_getMat[[4]]
      covarF_inv <- chol2inv(chol(covarF)) #solve(covarF)
      meanF <- matrix(0,length(meanF))
    } else {
      
      # 4) decide lambda
      if(l_in>l_out){ 
        lambdas <- append(lambdas,l_in)
        f <- f[f != i_in] # remove i_in within f
        w[i_in]=bi_in # set value at the correct boundary
      }else{
        lambdas <- append(lambdas,l_out)
        f <- append(f,i_out) # append i_out into f
      }
      temp_getMat <- getMatrices(mean, covar,solution_set, f)
      covarF <- temp_getMat[[1]]
      covarFB <- temp_getMat[[2]]
      meanF <- temp_getMat[[3]]
      wB <- temp_getMat[[4]]
      covarF_inv <- chol2inv(chol(covarF)) #solve(covarF)
    }
    
    # 5) compute solution vector
    temp_compW <- computeW(lambdas,covarF_inv,covarFB,meanF,wB)
    wF <- temp_compW[[1]]
    g <- temp_compW[[2]]
    for(i in seq(length(f))){
      w[f[i]]=wF[i]
    }
    solution_set <- cbind(solution_set, w) # store solution
    gammas <- append(gammas, g)
    free_weights <- append(free_weights, as.data.frame(f))
    if(lambdas[length(lambdas)] == 0) {
      break 
    }
  } #end While
  
  
  #temp_pNE <- purgeNummErr(free_weights, gammas, lambdas, lB, uB, solution_set, 1e-09) 
  #solution_set <- temp_pNE[[1]]
  #lambdas <- temp_pNE[[2]]
  #gammas <- temp_pNE[[3]]
  #free_weights <- temp_pNE[[4]]
  
  #temp_purgeEx <- purgeExcess(mean, lambdas, gammas, free_weights, solution_set)
  #solution_set <- temp_purgeEx[[1]]
  #lambdas <- temp_purgeEx[[2]]
  #gammas <- temp_purgeEx[[3]]
  #free_weights <- temp_purgeEx[[4]]
  
  ans <- list(mean, covar, solution_set, free_weights, gammas, lambdas)
  return(ans)
}