MS <- function(solution_set, mu, covar){
  if(length(solution_set)!=0){ 
  Sig2 <- colSums(solution_set *(covar %*% solution_set) )
  cbind(Sig = sqrt(Sig2), Sig2 = Sig2, Mu = as.vector(t(solution_set) %*% mu))
  } else NA
}

MS_plot <- function(ms, col = "blue"){  #list of solution_set, legend...
  plot(ms[,"Sig2"], ms[,"Mu"], type = "o", pch = 16, col = adjustcolor(col, alpha.f = 0.5),
       main = "Efficient Frontier", xlab = expression(mu),
       ylab = expression(sigma^2))
}

Total.plot <- function(ms.list){
  MS_plot(ms.list[[1]])
  if(length(ms.list) >1){
    for (i in 2:length(ms.list)){
      points(ms.list[[i]][,"Sig2"], ms.list[[i]][,"Mu"] , pch = 16, col = adjustcolor(col = i, alpha.f = 0.5))
    }
  }
  legend("bottomright", 
         legend = names(ms.list),
         lty = 1, col = c("blue", 2:length(ms.list)), pch = 16)
  
} 


# piecewise hyperbolic on Efficient Frontier, return cov of mu_in
hyperbolic <- function(mu_in, w1, w2, Mu, Cov){  
  mu1 <- sum(Mu * w1)   # mu1 > mu2
  mu2 <- sum(Mu * w2)
  lambda <- (mu_in - mu1)/(mu2 - mu1)
  w_in <- (1-lambda)*w1 + lambda*w2
  sum(w_in * (Cov %*% w_in))  # sig2 of mu_in
}

compareEF <- function(w.qp, w.cla, Mu, Cov, tol = -16){
  ms.qp <- MS(w.qp, Mu, Cov)
  ms.cla <- MS(w.cla, Mu, Cov)
  if(!anyNA(ms.qp, ms.cla)){ 
    ind <- (ms.qp[, "Mu"] <= max(ms.cla[, "Mu"]))&(ms.qp[, "Mu"] >= min(ms.cla[, "Mu"]))
    Sig2.cla <- sapply(which(ind), function(i){j <- sum(ms.cla[, "Mu"] > ms.qp[i, "Mu"])
    hyperbolic(ms.qp[i, "Mu"], w.cla[,j], w.cla[,j+1], Mu, Cov)})
    Sig2.qp <- ms.qp[ind, "Sig2"]
    cbind(index = which(ind),  Sig2.cla, Sig2.qp,
          diff = Sig2.cla-Sig2.qp,  # Sig2.cla - Sig2.qp
          tol = Sig2.cla-Sig2.qp > 10^tol )
  } else NA
}




