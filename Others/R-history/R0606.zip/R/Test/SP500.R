if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
# SP500, 476 assets, 265 observations
index.df["SP500",]

## preparing index
if(!file.exists(d.file("ind_SP500.rds", exists = FALSE))){
  n.sp <- ncol(SP500)
  ee <- exp_ind(1.2, 50, n) #at least 50 assets, at most 1457 assets, index power of 1.2
  # if 1.1, too much to plot and compute; if 1.3 or larger, too little information.
  set.seed(2017)
  ind.sp <- list()
  for(i in 1:length(ee$power)){
    ind.sp[[i]] <- lapply(rep(ee$ind[i], 50), function(x) sample(1:n, x, replace = FALSE))
  }
  saveRDS(ind.sp, d.file("ind_SP500.rds", exists = FALSE))
}
ind.sp <- readRDS( d.file("ind_SP500.rds", exists = FALSE))
l.sp <- length(ind.sp)
n.sp <- ncol(SP500)
label.sp <- exp_ind(1.2, 50, n.sp)$ind

## data and result set
for(i in 1:l.sp){#length(ind.sp)
  for(j in 1:10){
    if( !file.exists(d.file(paste("SP", length(ind.sp[[i]][[1]]), "_set", j, ".rds", sep = ""), 
                            exists = FALSE))){ 
      ind <- ind.sp[[i]][[j]]
      sp <- GetIndex(ind, SP500)
      weights.compare <- w.compare2(sp$mu, sp$covar, 
                                    sp$lB, sp$uB)
      saveRDS(weights.compare, d.file(paste("SP", length(ind.sp[[i]][[1]]), "_set", j, sep = ""), 
                                      exists = FALSE)) 
      saveRDS(sp, d.file(paste("SP", length(ind.sp[[i]][[1]]), "_data", j, ".rds", sep = ""), exists = FALSE)) 
      #eg. sp55_data1: 55 assets in total, with 1th indices set
      #    sp55_set1: the result of sp55_data1 
    }
  }
}

# analysis_SP: 
if(!file.exists(d.file("analysis_SP.rds"))){ 
  cla.sp <- list()
  t_compare.sp <- list()
  nweights.sp <- matrix(0, ncol = l.sp, nrow = 10)
  nweights.sp_unpurge <- matrix(0, ncol = l.sp, nrow = 10)
  covF.kappa.sp <- matrix(0, ncol = l.sp, nrow = 10)
  covF.rcond.sp <- matrix(0, ncol = l.sp, nrow = 10)
  cov.check.sp <- matrix(0, ncol = l.sp, nrow = 10)
  covF.sp <- list() # 8 sub-list, each with 10 sub-list, with cla-result of covFs
  lambda.sp <- list()
  for(i in 1:l.sp){
    re <- lapply(1:10, function(x)
      readRDS(d.file(paste("SP", length(ind.sp[[i]][[1]]), "_set", x, ".rds", sep = ""), 
                     exists = FALSE)))
    
    
    cla.sp[[i]] <- lapply(1:10, function(x)re[[x]]$result.cla)
    lambda.sp[[i]] <- lapply(1:10, function(x)re[[x]]$lambda.qp)
    t_compare.sp[[i]] <- sapply(1:10, function(x) {micro <- re[[x]]$micro
    unname(sapply(levels(micro$expr), 
                  function(y){median(micro$time[micro$expr==y])*1e-6}))}) 
    #take the median, miliseconds 
    
    nweights.sp[, i] <- sapply(1:10, function(x) ncol(cla.sp[[i]][[x]]$weights_set_purge))
    nweights.sp_unpurge[,i] <- sapply(1:10, function(x) ncol(cla.sp[[i]][[x]]$weights_set))
    
    covF.sp[[i]] <- lapply(1:10, function(x) lapply(cla.sp[[i]][[x]]$covarF, as.matrix))
    covF.kappa.sp[, i] <- sapply(1:10,function(x) max(sapply(covF.sp[[i]][[x]], kappa)))
    covF.rcond.sp[, i] <- sapply(1:10,function(x) min(sapply(covF.sp[[i]][[x]], rcond)))
    cov.check.sp[, i] <- sapply(1:10, function(x) is.positive.definite(readRDS(d.file(
      paste("SP", length(ind.sp[[i]][[x]]), "_data", 1, ".rds", sep = ""), 
                                        exists = FALSE))$covar) )
  }
  colnames(nweights.sp) <- label.sp
  colnames(nweights.sp_unpurge) <- label.sp
  colnames(cov.check.sp) <- label.sp
  colnames(covF.kappa.sp) <- label.sp
  colnames(covF.rcond.sp) <- label.sp
  analysis.sp <- list(cla_result = cla.sp,
                      t_compare = t_compare.sp,
                      nweights = nweights.sp,
                      nweights_unpurge = nweights.sp_unpurge,
                      covF.kappa = covF.kappa.sp,
                      covF.rcond = covF.rcond.sp,
                      covF = covF.sp,
                      cov.check = cov.check.sp,
                      lambda.QP = lambda.sp)
  saveRDS(analysis.sp, d.file("analysis_SP.rds", exists = FALSE))
}
analysis.sp <- readRDS(d.file("analysis_SP.rds", exists = FALSE))

#######################################################################################
#Plotting
# nweights_ind_boxplot
boxplot(analysis.sp$nweights, xlab = "Number of Assets", ylab = "Number", 
        main = "Number of Weights Sets", xaxt = "n")
axis(1, at = seq(l.sp), labels = label.sp )

# nweights_ind_plot
plot(apply(analysis.sp$nweights, 2, mean), 
     ylim = range(c(analysis.sp$nweights, analysis.sp$nweights_unpurge)), 
     pch = 16, col = "red",
     xlab = "Number of Assets", ylab = "Number", type = "o",
     main = "Number of Weights Sets", xaxt = "n")
axis(1, at = seq(l.sp), labels = label.sp)
lapply(1:10, function(x) points(analysis.sp$nweights[x,], pch = 16, 
                                col = adjustcolor("blue", 0.5)))
lapply(1:10, function(x) points(analysis.sp$nweights_unpurge[x,], pch = 16, 
                                col = adjustcolor("yellow", 0.5)))
legend("topleft", legend = c("mean-purge", "purge", "unpurge"), 
       col = c("red", "blue", "yellow"), lwd = 1, pch =16)

# kappa
boxplot(analysis.sp$covF.kappa, xlab = "Number of Assets", ylab = "kappa", 
        main = "Max-kappa of CovF", xaxt = "n")
axis(1, at = seq(l.sp), labels = label.sp)

# rcond
boxplot(analysis.sp$covF.rcond, xlab = "Number of Assets", ylab = "rcond", 
        main = "Min-rcond of CovF", xaxt = "n")
axis(1, at = seq(l.sp), labels = label.sp)

# sp_t_compare, mean
t_mean <- sapply(seq(l.sp), function(x) apply(analysis.sp$t_compare[[x]], 1, mean))
colnames(t_mean) <-  label.sp
plot(rep(1, 20), as.vector(analysis.sp$t_compare[[1]]), 
     col = rep(c(adjustcolor("red", 0.3), adjustcolor("blue", 0.3)), 
               10), 
     xlim = c(1, l.sp), ylim = range(analysis.sp$t_compare), xaxt = "n", pch = 16, 
     xlab = "Number of Assets", ylab = "milliseconds", main = "Time Comparison")
axis(1, at = seq(l.sp), labels = label.sp)
lapply(2:l.sp, function(x) 
  points(rep(x, 20), as.vector(analysis.sp$t_compare[[x]]), pch = 16,
         col = rep(c(adjustcolor("red", 0.3), adjustcolor("blue", 0.3)), 
                   10, 10)))
lines(t_mean[1,], col = "red")
lines(t_mean[2,], col = "blue")
legend("topleft", legend = c("cla", "qp"), col = c("red", "blue"), 
       pch = 16)

  # time of qp dropped sharply at 285, why?? 
which(label.sp == 285) #10
analysis.sp$lambda.QP[[10]]  # numeric(0)
sp <- GetIndex(ind.sp[[10]][[1]], SP500)
QP.solve(sp$mu, sp$covar, sp$lB, sp$uB, 0.3)
# error1: D(i.e covariance matrix not positive definite)
analysis.sp$cov.check # is.positive.definite = FALSE for last 3 columns

if(!file.exists(d.file("near_check_SP.rds"))){
  set.seed(2017)
  l <- list()
  near.check.sp <- matrix(0, ncol = 10, nrow = 20)
  for(j in 1:10){
    l[[j]] <- lapply(1:20, function(x) sample(seq(n.sp), j+260)) # 261-270 assets
    near.check.sp[, j] <- sapply(1:20, function(x) 
      is.positive.definite(GetIndex(l[[j]][[x]], SP500)$covar))
  }
  colnames(near.check.sp) <- 261:270
  saveRDS(near.check.sp, d.file("near_check_SP.rds", exists = FALSE))
}
near.check.sp <- readRDS(d.file("near_check_SP.rds", exists = FALSE))
near.check.sp # continuous?

# t_compare_cla_qp
plot(seq(l.sp), t_mean[1,], type = "o", ylim = range(t_mean), col = "red", 
     pch = 16, xaxt = "n", xlab = "Number of Assets", 
     ylab = "milliseconds", main = "Time Comparison of CLA and QP")
lines(seq(l.sp), t_mean[2,], col = "blue", pch = 16, type = "o")
axis(1, at = seq(l.sp),labels = label.sp)
legend("topleft", legend = c("cla", "qp"), col = c("red", "blue"), lwd = 1, pch = 16)

# qp method is faster than cla when the number of assets is small, (55-95)
# but much slower when number of assets is larger (114-410)

nlambda.QP <- matrix(0, ncol = l.sp, nrow = 10)
for(i in seq(l.sp)){
  nlambda.QP[,i] <- sapply(1:10, function(x) length(analysis.sp$lambda.QP[[i]][[x]]))
}
colnames(nlambda.QP) <- label.sp 
nlambda.QP
#eg. ind.sp[[1]][[1]]
nw <- analysis.sp$nweights[1,1]
lam.err <- setdiff(((1:nw)/nw)^2, lambda.sp[[1]][[1]])
sp <- GetIndex(ind.sp[[1]][[1]], SP500)
QP.solve(sp$mu, sp$covar, sp$lB, sp$uB, lam.err[1]) 
# error 2: constraints are inconsistent, no solution
