# eg
company79_set1 <- readRDS(d.file("Company79_set1.rds", exist = FALSE))
campany79_data1 <- readRDS(d.file("Company79_data1.rds", exists = FALSE))

w.cla <- company79_set1$weights$w.cla
w.qp <- company79_set1$weights$w.qp
hyperbolic(mean(c(w.cla[,1], w.cla[,2])), w.cla[,1], w.cla[,2], 
           campany79_data1$mu, campany79_data1$covar)

compareEF(w.qp, w.cla, campany79_data1$mu, campany79_data1$covar)

Total.plot(company79_set1$MS)

Total.plot(company79_set1$MS[1])
