if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################



assets <- GetAssets(1:20, assets1457)
assets<-GetIndex(1:20, transIndex(SP500))
mu <- assets$mu; covar <- assets$covar; 
lB <- assets$lB; uB <- assets$uB

lB <- runif(20, 0.0001, 0.001)
uB <- runif(20, 0.07, 0.08)

r1 <- CLA$M1(mu, covar, lB, uB)
r2 <- CLA$M2(mu, covar, lB, uB)
r3 <- CLA$M3(mu, covar, lB, uB)
r4 <- CLA$M4(mu, covar, lB, uB)
r5 <- CLA$M5(mu, covar, lB, uB)
#########
all.equal(CLA$M3(mu, covar, lB, uB), r3)

w <- r4$weights_set
w0 <- r4$weights_set0
all.equal(w, w0)

r4$weights_set_purge
all.equal(w[,1], w[,2])
w[,1:4]
debug(Env4$cla.solver)
Env4$cla.solver(mu, covar, lB, uB)

version.compare(20, times = 1, versions = c(3, 1))

source("main.R")
lapply(seq(20, 120, 20), function(x) {
  version.compare(x, 1, versions = c(3,5))$micro
})

###########################

w <- addW(uniqueW(r3$weights_set))
w[,purgeChull(w, mu, covar)]



addW(r3$weights_set)

adw<-addW(r3$weights_set_purge)$weights_set_new
adwn <- adw[,purgeChull(adw, mu, covar)]

rr <- lapply(1:ncol(adwn), function(x)(
  which( !(abs(adwn[,x]-1e-8)< 1e-10| abs(adwn[,x]- 0.075)<1e-10))
))

dif <- sapply(1:(ncol(adwn)-1), function(x) 
  all.equal(rr[[x+1]],rr[[x]])==TRUE)
dif
which(dif) # 4 7 10 13
h <- c()
for(j in which(dif)){
  ms <- MS(adwn[,(j-1):(j+2)], mu, covar)
  # test jth
  h1 <- hyperbolic(mu_in = ms[2,3], adwn[,j-1],adwn[,j+1], mu, covar  )-ms[2,2]# >0
  h2 <- hyperbolic(mu_in = ms[3,3], adwn[,j],adwn[,j+2], mu, covar  )-ms[3,2] # >0
  h <- c(h,h1,h2)
}

j-1
j #same
j+1 #same
j+2 

