version.compare <- function(assets, methods=0, times){
  
  micro <- microbenchmark(r1 <- CLA$M2(assets$mu, assets$covar, assets$lB, assets$uB),
                          r2 <- CLA$M3(assets$mu, assets$covar, assets$lB, assets$uB),
                          times = times)
  list(micro = micro, is.equal = all.equal(r1, r2))
  
}

assets <- readRDS(d.file("Company50.rds"))
version.compare(readRDS(d.file("Company50.rds")), times =1)

