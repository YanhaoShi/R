if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
# NASDAQ
index.df["NASDAQ",] # 2196 assets, 265 observations
analysis.nasdaq <- IndexAnalysis(Index.trans = transIndex(NASDAQ), name = "nasdaq")

#######################################################################################
# plot
IndexPlot(analysis.nasdaq, ncol(NASDAQ), "nasdaq")  # open sp_plot.pdf


#########################################################################################
if(!file.exists(d.file("ind_nasdaq.rds", exists = FALSE))){
  n <- ncol(NASDAQ)
  ee <- exp_ind(1.2, 50, n) #at least 50 assets, at most 1457 assets, index power of 1.2
  # if 1.1, too much to plot and compute; if 1.3 or larger, too little information.
  set.seed(2017)
  ind.nasdaq <- list()
  for(i in 1:length(ee$power)){
    ind.nasdaq[[i]] <- lapply(rep(ee$ind[i], 50), function(x) sample(1:n, x, replace = FALSE))
  }
  saveRDS(ind.nasdaq, d.file("ind_NASDAQ.rds", exists = FALSE))
}
ind.nasdaq <- readRDS( d.file("ind_NASDAQ.rds", exists = FALSE))
l.nasdaq <- length(ind.nasdaq)
n.nasdaq <- ncol(NASDAQ)
label.nasdaq <- exp_ind(1.2, 50, n.nasdaq)$ind

for(i in 1:length(ind.nasdaq)){#length(ind.nasdaq)
  for(j in 1:10){
    if( !file.exists(d.file(paste("NASDAQ", length(ind.nasdaq[[i]][[1]]), "_set", j, sep = ""), 
                            exists = FALSE))){ 
      ind <- ind.nasdaq[[i]][[j]]
      nasdaq <- GetIndex(ind, NASDAQ)
      weights.compare <- w.compare2(nasdaq$mu, nasdaq$covar, 
                                    nasdaq$lB, nasdaq$uB)
      saveRDS(weights.compare, d.file(paste("NASDAQ", length(ind.nasdaq[[i]][[1]]), "_set", j, sep = ""), 
                                      exists = FALSE)) 
      saveRDS(nasdaq, d.file(paste("NASDAQ", length(ind.nasdaq[[i]][[1]]), "_data", j, sep = ""), exists = FALSE)) 
      #eg. NASDAQ_data1: 55 assets in total, with 1th indices set
      #    NASDAQ_set1: the result of nasdaq55_data1 
    }
  }
}

##draft
for(i in 18:21){  ##change to 18:21
  for(j in 1:10){
    nas <- readRDS(d.file(paste("NASDAQ", length(ind.nasdaq[[i]][[1]]), "_set", j, sep = ""),exists = F))
    saveRDS(nas, d.file(paste("NASDAQ", length(ind.nasdaq[[i]][[1]]), "_set", j, ".rds", sep = ""),exists = F))
  }
}

for(i in 1:l.nasdaq){
  for(j in 1:10){
    nas <- readRDS(d.file(paste("NASDAQ", length(ind.nasdaq[[i]][[1]]), "_data", j, sep = ""),exists = F))
    saveRDS(nas, d.file(paste("NASDAQ", length(ind.nasdaq[[i]][[1]]), "_data", j, ".rds", sep = ""),exists = F))
  }
}
#######
##draft:
l.nasdaq=16
label.nasdaq <- label.nasdaq[1:16]
####
# analysis_SP: 
if(!file.exists(d.file("analysis_NASDAQ.rds", exists = FALSE))){ 
  cla.nasdaq <- list()
  t_compare.nasdaq <- list()
  nweights.nasdaq <- matrix(0, ncol = l.nasdaq, nrow = 10)
  nweights.nasdaq_unpurge <- matrix(0, ncol = l.nasdaq, nrow = 10)
  covF.kappa.nasdaq <- matrix(0, ncol = l.nasdaq, nrow = 10)
  covF.rcond.nasdaq <- matrix(0, ncol = l.nasdaq, nrow = 10)
  cov.check.nasdaq <- matrix(0, ncol = l.nasdaq, nrow = 10)
  covF.nasdaq <- list() # 8 sub-list, each with 10 sub-list, with cla-result of covFs
  lambda.nasdaq <- list()
  for(i in 1:l.nasdaq){
    re <- lapply(1:10, function(x)
      readRDS(d.file(paste("NASDAQ", length(ind.nasdaq[[i]][[1]]), "_set", x, ".rds", sep = ""), 
                     exists = FALSE)))
    
    
    cla.nasdaq[[i]] <- lapply(1:10, function(x)re[[x]]$result.cla)
    lambda.nasdaq[[i]] <- lapply(1:10, function(x)re[[x]]$lambda.qp)
    t_compare.nasdaq[[i]] <- sapply(1:10, function(x) {micro <- re[[x]]$micro
    unname(sapply(levels(micro$expr), 
                  function(y){median(micro$time[micro$expr==y])*1e-6}))}) 
    #take the median, miliseconds 
    
    nweights.nasdaq[, i] <- sapply(1:10, function(x) ncol(cla.nasdaq[[i]][[x]]$weights_set_purge))
    nweights.nasdaq_unpurge[,i] <- sapply(1:10, function(x) ncol(cla.nasdaq[[i]][[x]]$weights_set))
    
    covF.nasdaq[[i]] <- lapply(1:10, function(x) lapply(cla.nasdaq[[i]][[x]]$covarF, as.matrix))
    covF.kappa.nasdaq[, i] <- sapply(1:10,function(x) max(sapply(covF.nasdaq[[i]][[x]], kappa)))
    covF.rcond.nasdaq[, i] <- sapply(1:10,function(x) min(sapply(covF.nasdaq[[i]][[x]], rcond)))
    cov.check.nasdaq[, i] <- sapply(1:10, function(x) is.positive.definite(readRDS(d.file(
      paste("NASDAQ", length(ind.nasdaq[[i]][[x]]), "_data", 1, ".rds", sep = ""), 
      exists = FALSE))$covar) )
  }
  colnames(nweights.nasdaq) <- label.nasdaq
  colnames(nweights.nasdaq_unpurge) <- label.nasdaq
  colnames(cov.check.nasdaq) <- label.nasdaq
  colnames(covF.kappa.nasdaq) <- label.nasdaq
  colnames(covF.rcond.nasdaq) <- label.nasdaq
  analysis.nasdaq <- list(cla_result = cla.nasdaq,
                      t_compare = t_compare.nasdaq,
                      nweights = nweights.nasdaq,
                      nweights_unpurge = nweights.nasdaq_unpurge,
                      covF.kappa = covF.kappa.nasdaq,
                      covF.rcond = covF.rcond.nasdaq,
                      covF = covF.nasdaq,
                      cov.check = cov.check.nasdaq,
                      lambda.QP = lambda.nasdaq)
  saveRDS(analysis.nasdaq, d.file("analysis_NASDAQ.rds", exists = FALSE))
}
analysis.nasdaq <- readRDS(d.file("analysis_NASDAQ.rds", exists = FALSE))

#######################################################################################
#Plotting
# nasdaq_nweights
boxplot(analysis.nasdaq$nweights, xlab = "Number of Assets", ylab = "Number", 
        main = "Number of Weights Sets", xaxt = "n")
axis(1, at = seq(l.nasdaq), labels = label.nasdaq )

# nasdaq_nweights_plot
plot(apply(analysis.nasdaq$nweights, 2, mean), 
     ylim = range(c(analysis.nasdaq$nweights, analysis.nasdaq$nweights_unpurge)), 
     pch = 16, col = "red",
     xlab = "Number of Assets", ylab = "Number", type = "o",
     main = "Number of Weights Sets", xaxt = "n")
axis(1, at = seq(l.nasdaq), labels = label.nasdaq)
lapply(1:10, function(x) points(analysis.nasdaq$nweights[x,], pch = 16, 
                                col = adjustcolor("blue", 0.5)))
lapply(1:10, function(x) points(analysis.nasdaq$nweights_unpurge[x,], pch = 16, 
                                col = adjustcolor("yellow", 0.5)))
legend("topleft", legend = c("mean-purge", "purge", "unpurge"), 
       col = c("red", "blue", "yellow"), lwd = 1, pch =16)

# nasdaq_kappa
boxplot(analysis.nasdaq$covF.kappa, xlab = "Number of Assets", ylab = "kappa", 
        main = "Max-kappa of CovF", xaxt = "n")
axis(1, at = seq(l.nasdaq), labels = label.nasdaq)

# nasdaq_rcond
boxplot(analysis.nasdaq$covF.rcond, xlab = "Number of Assets", ylab = "rcond", 
        main = "Min-rcond of CovF", xaxt = "n")
axis(1, at = seq(l.nasdaq), labels = label.nasdaq)

# nasdaq_t_compare, mean
t_mean <- sapply(seq(l.nasdaq), function(x) apply(analysis.nasdaq$t_compare[[x]], 1, mean))
colnames(t_mean) <-  label.nasdaq
plot(rep(1, 20), as.vector(analysis.nasdaq$t_compare[[1]]), 
     col = rep(c(adjustcolor("red", 0.3), adjustcolor("blue", 0.3)), 10), 
     xlim = c(1, l.nasdaq), ylim = range(analysis.nasdaq$t_compare), xaxt = "n", pch = 16, 
     xlab = "Number of Assets", ylab = "milliseconds", main = "Time Comparison")
axis(1, at = seq(l.nasdaq), labels = label.nasdaq)
lapply(2:l.nasdaq, function(x) 
  points(rep(x, 20), as.vector(analysis.nasdaq$t_compare[[x]]), pch = 16,
         col = rep(c(adjustcolor("red", 0.3), adjustcolor("blue", 0.3)), 
                   10, 10)))
lines(t_mean[1,], col = adjustcolor("red", 0.5))
lines(t_mean[2,], col = adjustcolor("blue", 0.5))
legend("topleft", legend = c("cla", "qp"), col = c("red", "blue"), 
       pch = 16)

# time of qp dropped sharply at 285, why?? SP500?
which(label.nasdaq == 285) #10
analysis.nasdaq$lambda.QP[[10]]  # numeric(0)
nasdaq <- GetIndex(ind.nasdaq[[10]][[1]], NASDAQ)
QP.solve(nasdaq$mu, nasdaq$covar, nasdaq$lB, nasdaq$uB, 0.3)
# error1: D(i.e covariance matrix not positive definite)
analysis.nasdaq$cov.check # is.positive.definite = FALSE for last 3 columns

if(!file.exists(d.file("near_check_NASDAQ.rds", exists = FALSE))){
  set.seed(2017)
  l <- list()
  k <- 10
  near.check.nasdaq <- matrix(0, ncol = 10, nrow = k)
  for(j in 1:10){
    l[[j]] <- lapply(1:k, function(x) sample(seq(n.nasdaq), j+260)) # 251-270 assets
    near.check.nasdaq[, j] <- sapply(1:k, function(x) 
      is.positive.definite(GetIndex(l[[j]][[x]], NASDAQ)$covar))
  }
  saveRDS(near.check.nasdaq, d.file("near_check_NASDAQ.rds", exists = FALSE))
}
near.check.nasdaq <- readRDS(d.file("near_check_NASDAQ.rds", exists = FALSE))
near.check.nasdaq # continuous?




# t_compare_cla_qp
plot(seq(l.nasdaq), t_mean[1,], type = "o", ylim = range(t_mean), col = "red", 
     pch = 16, xaxt = "n", xlab = "Number of Assets", 
     ylab = "milliseconds", main = "Time Comparison of CLA and QP")
lines(seq(l.nasdaq), t_mean[2,], col = "blue", pch = 16, type = "o")
axis(1, at = seq(l.nasdaq),labels = label.nasdaq)
legend("topleft", legend = c("cla", "qp"), col = c("red", "blue"), lwd = 1, pch = 16)

# qp method is faster than cla when the number of assets is small, (55-95)
# but much slower when number of assets is larger (114-410)

nlambda.QP <- matrix(0, ncol = l.nasdaq, nrow = 10)
for(i in seq(l.nasdaq)){
  nlambda.QP[,i] <- sapply(1:10, function(x) length(analysis.nasdaq$lambda.QP[[i]][[x]]))
}
colnames(nlambda.QP) <- label.nasdaq 
nlambda.QP
#eg. ind.nasdaq[[1]][[1]]
nw <- analysis.nasdaq$nweights[1,1]
lam.err <- setdiff(((1:nw)/nw)^2, lambda.nasdaq[[1]][[1]])
nasdaq <- GetIndex(ind.nasdaq[[1]][[1]], NASDAQ)
QP.solve(nasdaq$mu, nasdaq$covar, nasdaq$lB, nasdaq$uB, lam.err[1]) 
# error 2: constraints are inconsistent, no solution

################################################################################
grid::grid.raster(readPNG(d.file("nasdaq_nweights.png", exists = F)))
grid::grid.raster(readPNG(d.file("nasdaq_nweights_plot.png", exists = F)))
grid::grid.raster(readPNG(d.file("nasdaq_kappa.png", exists = F)))
grid::grid.raster(readPNG(d.file("nasdaq_rcond.png", exists = F)))
grid::grid.raster(readPNG(d.file("nasdaq_t_compare.png", exists = F)))

