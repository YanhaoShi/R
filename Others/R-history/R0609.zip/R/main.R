## Set up #####
if(!file.exists("init.R")) stop("R directory does *not* contain init.R")
source("init.R")
#######################################################################################
## 1) Packages Required
pa <- c("microbenchmark", "Matrix", "compiler", "png",
        "FRAPO", "ghyp", "Rcpp", "quadprog", "matrixcalc")
for (package in pa) {
  if (!require(package, character.only=T, quietly=T)) {
    install.packages(package)
    library(package, character.only=T)
  }
}

## 2) Import data ####
# Raw company data
if(!file.exists(d.file("company_assets.rds", exists = FALSE))){
  saveRDS(read.table(d.file('03-02_CLA_Data_Tot.csv'), header = TRUE, sep = ','), 
          d.file("company_assets.rds", exists = FALSE))
}
company_assets <- readRDS(d.file("company_assets.rds", exists = FALSE))

# Total assets: assets 1457 
if(!file.exists(d.file("assets1457.rds", exists = FALSE))){
  transData <- function(d){
    n <- ncol(company_assets)
    assets <- as.matrix(t(d[1:3, 1:n]))
    colnames(assets) <- c("mu", "lB", "uB")
    covar <- as.matrix(d[4:(n+3), 1:n ])
    rownames(covar) <- colnames(covar)
    list(assets = assets, covar = covar)
  }
  # for function input
  getData <- function(d){
    row.names(d$assets) <- NULL
    mu <- as.matrix(d$assets[, "mu"])
    lB <- as.matrix(d$assets[, "lB"])
    uB <- as.matrix(d$assets[, "uB"])
    colnames(d$covar) <- NULL
    rownames(d$covar) <- NULL
    covar <- d$covar
    list(mu = mu, lB = lB, uB = uB, covar = covar)
  }
  
  if(!file.exists(d.file("trans_company_assets.rds", exists = FALSE))){
    saveRDS(transData(company_assets), 
            d.file("trans_company_assets.rds", exists = FALSE))
  }
  saveRDS(getData(transData(company_assets)), d.file("assets1457", exists = FALSE))
}
assets1457 <- readRDS(d.file("assets1457.rds", exists = FALSE))

# the corresponding assets under a given set of indices from the total assets
GetAssets <- function(ind, total_assets){
  list(mu = total_assets$mu[ind, , drop = FALSE], lB = total_assets$lB[ind, , drop = FALSE], 
       uB = total_assets$uB[ind, , drop = FALSE], covar = total_assets$covar[ind, ind])
}

## 3) Created data for validating
validate <- function(n, m){   # n number of assets, m columns of solution_sets
  set.seed(1)
  a <- matrix(runif(n*m,0,1/n),nrow=n)
  a[n,] <- 1- colSums(a[-n,]) + sample(c(-1,0,1), m, replace = T, prob = c(1/m,(m-2)/m,1/m))* 1e-4
  lB <- apply(a,1,min) - sample(c(0,1),n,replace=T,prob=c(3/4,1/4))*1e-4
  uB <- apply(a,1,max) + sample(c(0,1),n,replace=T,prob=c(3/4,1/4))*1e-4
  covar <- matrix(runif(n^2,0,1), n, n)
  mu <- 1:n
  i <- floor(n*0.6)
  list( mu = mu, lB = lB,uB = uB, solution_set = a,
        gammas = 1:m, lambdas = 1:m, free_weights = 1:i,
        covar = covar, covarF = covar[1:i,1:i], covarF_inv = solve(covar[1:i,1:i]),
        covarFB = covar[1:i, (i+1):n], meanF = mu[1:i], wB = runif(n-i,0,1)/(n-i),
        f = 1:i
  )
} 

# corresponding index for company assets, each for 50 times
if(!file.exists(d.file("ind_company.rds", exists = FALSE))){
  ee <- exp_ind(1.2, 50, 1457) #at least 50 assets, at most 1457 assets, index power of 1.2
  # if 1.1, too much to plot and compute; if 1.3 or larger, too little information.
  set.seed(2017)
  ind.company <- list()
  for(i in 1:length(ee$power)){
    ind.company[[i]] <- lapply(rep(ee$ind[i], 50), function(x) sample(seq(1457), x, replace = FALSE))
  }
  saveRDS(ind.company, d.file("ind_company.rds", exists = FALSE))
}
ind.company <- readRDS(d.file("ind_company.rds", exists = FALSE)) 

## 4) check index data in FRAPO package
if(!file.exists(d.file("indexdf", exists = FALSE))){
  index <- list(ESCBFX = ESCBFX, EuroStoxx50 = EuroStoxx50, FTSE100 = FTSE100, 
                INDTRACK1 = INDTRACK1, INDTRACK2 = INDTRACK2, 
                INDTRACK3 = INDTRACK3, INDTRACK4 = INDTRACK4, 
                INDTRACK5 = INDTRACK5, INDTRACK6 = INDTRACK6, 
                MIBTEL = MIBTEL, MultiAsset = MultiAsset, NASDAQ = NASDAQ, 
                SP500 = SP500, StockIndex = StockIndex, 
                StockIndexAdj = StockIndexAdj, StockIndexAdjD = StockIndexAdjD)
  index.df <- data.frame(assets = sapply(index, ncol),
                         observations = sapply(index, nrow),
                         start = sapply(index, function(x) 
                           ifelse(is.null(row.names(x)), 1, row.names(x)[1])),
                         end = sapply(index, function(x) 
                           ifelse(is.null(row.names(x)), nrow(x), row.names(x)[nrow(x)])))
  saveRDS(index.df, d.file("indexdf.rds", exists = FALSE))
}

trans <- function(Index){
  n <- ncol(Index)
  mu <- as.matrix(sapply(1:n, function(x) mean(Index[-1,x]/Index[-nrow(Index),x]-1)))
  # -> 264 observations
  cov <- cov(unname(Index))
  list(Mu = mu, Cov = cov)
}

GetIndex <- function(ind, Index, lB = as.matrix(rep(1e-8,length(ind))), 
                     uB = as.matrix(rep(0.075, length(ind)))){
  mu <- trans(Index)$Mu[ind]
  covar <- trans(Index)$Cov[ind, ind]
  list(mu = as.matrix(mu), covar = covar, lB = lB, uB = uB)
}

## 5) Source functions 
source("Functions/Ver1_previous.R")
source("Functions/Ver2_benchmark.R")
source("Functions/Ver3.R")

source("Functions/Other_approaches.R")
source("Functions/Compare_results.R")
source("Functions/Plot.R")
source("Functions/Index_Analysis.R")

## 6) three versions of CLA methods
CLA <- list(
  M1 = function(mean, covar, lB, uB){
    source("Functions/Ver1_previous.R")
    Method1$cla.solver(mean, covar, lB, uB)
  },
  M2 = function(mean, covar, lB, uB){
    source("Functions/Ver2_benchmark.R")
    Method2$cla.solver(mean, covar, lB, uB)
  },
  M3 = function(mean, covar, lB, uB){
    source("Functions/Ver3.R")
    Method2$cla.solver(mean, covar, lB, uB)
  },
  M4 = function(mean, covar, lB, uB){
    source("Functions/Ver2_benchmark.R")
    cmpfun(Method2$cla.solver)(mean, covar, lB, uB)  ## slower than ver 2!
  })

