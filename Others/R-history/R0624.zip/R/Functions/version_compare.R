version.compare <- function(assets.number, times, versions){
  assets <- GetAssets(1:assets.number, assets1457)
  micro <- microbenchmark(r1 <- CLA[[paste("M", versions[1], sep = "")]](assets$mu, assets$covar, assets$lB, assets$uB),
                          r2 <- CLA[[paste("M", versions[2], sep = "")]](assets$mu, assets$covar, assets$lB, assets$uB),
                          times = times)
  list(micro = micro, is.equal = all.equal(r1, r2),
       weight.equal = all.equal(r1$weights_set_purge, r2$weights_set_purge),
       free_indices.equal = all.equal(r1$free_indices, r2$free_indices))
  
}


