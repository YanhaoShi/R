# "true" free indices 
Wf <- function(weights_set){
  lapply(1:ncol(weights_set), function(x)(
    which( !(abs(weights_set[,x]-1e-8)< 1e-10| abs(weights_set[,x]- 0.075)<1e-10))
  ))
}

change_f <- function(f_ind){
  stopifnot((nf <- length(f_ind)) >= 2)
  ii <- seq_len(nf-1)
  lapply(ii, function(x) c(setdiff(f_ind[[x]], f_ind[[x+1]]), 
                                       setdiff(f_ind[[x+1]],f_ind[[x]])) )
  
  f2b <- sapply(1:(length(f_ind)-1), function(x){d <- setdiff(f_ind[[x]], f_ind[[x+1]])
                      ifelse(length(d)!=0, d, 0)}  )
  b2f <- sapply(1:(length(f_ind)-1), function(x) {d <- setdiff(f_ind[[x+1]], f_ind[[x]])
              ifelse(length(d)!=0, d, 0)} )
  rbind(f2b, b2f)
}

# remove replicated columns
uniqueW <- function(weights_set){
  ind.rep <- which(sapply(1:(ncol(weights_set)-1), function(x) 
    isTRUE(all.equal(weights_set[,x],weights_set[,x+1]))))
  weights_set[, -ind.rep]
}

addW <- function(weights_set, mu){
  n <- ncol(weights_set)
  f_ind <- Wf(weights_set)
  dif <- apply(change_f(f_ind) !=0, 2, sum)
  w_add <-c ()
  for(j in which(dif==2)){
    f2b <- setdiff(f_ind[[j]], f_ind[[j+1]]) #row
    w_in <- weights_set[,j]
    w_in[f2b] <- weights_set[f2b, j+1] # set free weight to the boundary
    ind <- intersect(f_ind[[j]], f_ind[[j+1]])
    w_in[ind] <-w_in[ind]/(sum(w_in[ind])) * (1-sum(w_in[-ind]))
    w_add <- cbind(w_add,w_in)
  }
  weights_set <- cbind(weights_set, w_add)
  weights_set[, order(t(weights_set) %*% mu, decreasing = TRUE)]
       
}

plotW <- function(weights_set, mu, covar){
  ind_p <- purgeChull(weights_set, mu, covar)
  pch <- rep(1, ncol(weights_set))
  pch[ind_p] <- 16
  col <- rep("blue", ncol(weights_set))
  col[ind_p] <- "blue"
  if(!is.null(colnames(weights_set))){  
    ind_in <- colnames(weights_set) == "w_in"
    col[ind_in] <- "red"}
  f.label <- change_f(Wf(weights_set))
  
  ms.w <- MS(weights_set, mu = mu, covar = covar)
  plot(ms.w[,"Sig2"], ms.w[,"Mu"], pch = pch, col = col)
  lines(ms.w[ind_p,"Sig2"], ms.w[ind_p,"Mu"], pch = 1, col = adjustcolor("blue", 0.5))
  ind1 <- f.label[1, ]!= 0
  ind2 <- f.label[2, ]!= 0
  text(ms.w[ind1, "Sig2"], ms.w[ind1, "Mu"], pos = 3, paste("+",f.label[1,ind1]), col = 1)
  text(ms.w[ind2, "Sig2"], ms.w[ind2, "Mu"], pos = 1, paste("-",f.label[2,ind2]), col = 1)
  legend("bottomright", legend = c("w", "w-in", "w-remove", "w-in-remove"), 
         col = c("blue", "red"), pch = c(16, 16, 1, 1), bty = "n")
}

.freeI2char <- function(f) paste0("(", paste(f, collapse=","), ")")
freeI2char <- function(fi) sapply(fi, .freeI2char)

assets <- GetAssets(1:20, assets1457)
r3 <- CLA$M3(assets$mu, assets$covar, assets$lB, assets$uB)
colSums(r3$weights_set)

Wf(uniqueW(r3$weights_set))
change_f(Wf(uniqueW(r3$weights_set)))
add.w <- addW(r3$weights_set, assets$mu)
plotW(addW(r3$weights_set, assets$mu), assets$mu, assets$covar) 
colSums(r3$weights_set)
ms.w <- MS(r3$weights_set, mu = assets$mu, covar = assets$covar)
options(digits=5)
data.frame(ms.w[,c("Mu", "Sig")], lambda =r3$lambdas, 
           gamma = r3$gammas, freeI = freeI2char(r3$free_indices))
## rows 8..10  and then 12..14 are identical .. why??