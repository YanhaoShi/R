##############################################################################################################
transIndex <- function(Index, lB = as.matrix(rep(1e-8, ncol(Index))), 
                  uB = as.matrix(rep(0.075, ncol(Index)))){
  n <- ncol(Index)
  mu <- as.matrix(sapply(1:n, function(x) mean(Index[-1,x]/Index[-nrow(Index),x]-1)))
  # -> 264 observations
  cov <- cov(unname(Index))
  list(mu = mu, cov = cov, lB = lB, uB = uB)
}

GetIndex <- function(ind, Index.trans){
  mu <- Index.trans$mu[ind]
  covar <- Index.trans$cov[ind, ind]
  lB <- Index.trans$lB[ind]
  uB <- Index.trans$uB[ind]
  list(mu = as.matrix(mu), covar = covar, lB = lB, uB = uB)
}

IndexAnalysis <- function(Index.trans, name, n) {# n assets: ncol (Index) n: eg410
  if(!file.exists(d.file(paste("ind_", name, ".rds", sep = ""), exists = FALSE))){           # ind_name
    ee <- exp_ind(1.2, 50, n) #at least 50 assets, at most n assets, index power of 1.2
    # if 1.1, too much to plot and compute; if 1.3 or larger, too little information.
    set.seed(2017)
    ind.list <- list()
    for(i in 1:length(ee$power)){
      ind.list[[i]] <- lapply(rep(ee$ind[i], 50), function(x) sample.int(n, x, replace = FALSE))
    }
    saveRDS(ind.list, d.file(paste("ind_", name, ".rds", sep = ""), exists = FALSE))
  }
  
  ind.list <- readRDS( d.file(paste("ind_", name, ".rds", sep = ""), exists = FALSE))
  l <- length(exp_ind(1.2, 50, n)$ind)
  label <- exp_ind(1.2, 50, n)$ind
  
  ## data and result set
  for(i in 1:l){
    for(j in 1:10){
      if( !file.exists(d.file(paste(toupper(name), length(ind.list[[i]][[1]]), "_set", j, ".rds", sep = ""), 
                              
                              exists = FALSE))){ 
        ind <- ind.list[[i]][[j]]
        assets <- GetIndex(ind, Index.trans)
        weights.compare <- w.compare2(assets$mu, assets$covar, 
                                      assets$lB, assets$uB)
        saveRDS(weights.compare, d.file(paste(toupper(name), length(ind.list[[i]][[1]]), "_set", j, sep = ""), 
                                        exists = FALSE)) 
        saveRDS(assets, d.file(paste(paste(toupper(name), length(ind.list[[i]][[1]]), "_data", j, ".rds", sep = ""), 
                                     exists = FALSE)))
        
      }
    }
  }
  
  # analysis_Index: 
  if(!file.exists(d.file(paste("analysis_", toupper(name),".rds", sep = ""), exists = FALSE))){ 
    cla <- list()
    t_compare <- list()
    nweights <- matrix(0, ncol = l, nrow = 10)
    nweights_unpurge <- matrix(0, ncol = l, nrow = 10)
    covF.kappa <- matrix(0, ncol = l, nrow = 10)
    covF.rcond <- matrix(0, ncol = l, nrow = 10)
    cov.check <- matrix(0, ncol = l, nrow = 10)
    covF <- list() # 8 sub-list, each with 10 sub-list, with cla-result of covFs
    lambda <- list()
    for(i in 1:l){
      re <- lapply(1:10, function(x)
        readRDS(d.file(paste(toupper(name), length(ind.list[[i]][[1]]), "_set", x, ".rds", sep = ""), 
                       exists = FALSE)))
        
        
        cla[[i]] <- lapply(1:10, function(x)re[[x]]$result.cla)
        lambda[[i]] <- lapply(1:10, function(x)re[[x]]$lambda.qp)
        t_compare[[i]] <- sapply(1:10, function(x) {micro <- re[[x]]$micro
        unname(sapply(levels(micro$expr), 
                      function(y){median(micro$time[micro$expr==y])*1e-6}))}) 
        #take the median, miliseconds 
        
        nweights[, i] <- sapply(1:10, function(x) ncol(cla[[i]][[x]]$weights_set_purge))
        nweights_unpurge[,i] <- sapply(1:10, function(x) ncol(cla[[i]][[x]]$weights_set))
        
        covF[[i]] <- lapply(1:10, function(x) lapply(cla[[i]][[x]]$covarF, as.matrix))
        covF.kappa[, i] <- sapply(1:10,function(x) max(sapply(covF[[i]][[x]], kappa)))
        covF.rcond[, i] <- sapply(1:10,function(x) min(sapply(covF[[i]][[x]], rcond)))
        cov.check[, i] <- sapply(1:10, function(x) is.positive.definite(readRDS(d.file(
          paste(toupper(name), length(ind.list[[i]][[x]]), "_data", 1, ".rds", sep = ""), 
          exists = FALSE))$covar) ) #check if the covariance matrix is positive definite
    }
    colnames(nweights) <- label
    colnames(nweights_unpurge) <- label
    colnames(cov.check) <- label
    colnames(covF.kappa) <- label
    colnames(covF.rcond) <- label
    t_mean <- sapply(seq(l), 
                     function(x) apply(t_compare[[x]], 1, mean))
    colnames(t_mean) <- label
    rownames(t_mean) <- c("cla", "qp", "cccp")[1:nrow(t_mean)]

    analysis <- list(cla_result = cla,
                     t_compare = t_compare,
                     t_mean = t_mean,
                     nweights = nweights,
                     nweights_unpurge = nweights_unpurge,
                     covF.kappa = covF.kappa,
                     covF.rcond = covF.rcond,
                     covF = covF,
                     cov.check = cov.check,
                     lambda.QP = lambda)
    saveRDS(analysis, d.file(paste("analysis_", toupper(name),".rds", sep = ""), exists = FALSE))
  }
  readRDS(d.file(paste("analysis_", toupper(name),".rds", sep = ""), exists = FALSE))
}

##############################################################################################################
IndexPlot <- function(analysis, name, n){
  pdf(d.file(paste(name, "_plot.pdf", sep = ""), exists = FALSE))  
  l <- length(exp_ind(1.2, 50, n)$ind)
  label <- exp_ind(1.2, 50, n)$ind
  
  # 1. nweights_ind_boxplot
  boxplot(analysis$nweights, xlab = "Number of Assets", ylab = "Number", 
          main = paste(name, "1. Number of Weights Sets", sep = ""), xaxt = "n") 
  axis(1, at = seq(l), labels = label)
  
  # 2. nweights_ind_plot
  plot(apply(analysis$nweights, 2, mean), 
       ylim = range(c(analysis$nweights, analysis$nweights_unpurge)), 
       pch = 16, col = "red",
       xlab = "Number of Assets", ylab = "Number", type = "o",
       main = paste(name, "2. Number of Weights Sets", sep = ""), xaxt = "n")
  axis(1, at = seq(l), labels = label)
  lapply(1:10, function(x) points(analysis$nweights[x,], pch = 16, 
                                  col = adjustcolor("blue", 0.5)))
  lapply(1:10, function(x) points(analysis$nweights_unpurge[x,], pch = 16, 
                                  col = adjustcolor("yellow", 0.5)))
  legend("topleft", legend = c("mean-purged", "purged", "unpurged"), 
         col = c("red", "blue", "yellow"), lwd = 1, pch =16)
  
  # 3. kappa
  boxplot(analysis$covF.kappa, xlab = "Number of Assets", ylab = "kappa", 
          main = paste(name, "3. Max-kappa of CovF", sep= ""), xaxt = "n")
  axis(1, at = seq(l), labels = label)
  
  # 4. rcond
  boxplot(analysis$covF.rcond, xlab = "Number of Assets", ylab = "rcond", 
          main = paste(name, "4. Min-rcond of CovF", sep =""), xaxt = "n")
  axis(1, at = seq(l), labels = label)
  
  # 5. t_compare, mean
  t_mean <- sapply(seq(l), function(x) apply(analysis$t_compare[[x]], 1, mean))
  colnames(t_mean) <-  label
  k <- nrow(t_mean)
  color <- c("red", "blue", "green")[1:k]
  color.adjust <- sapply(1:k, function(k) adjustcolor(color[k], 0.3))
  
  plot(rep(1, 10 * k), as.vector(analysis$t_compare[[1]]), 
       col = rep( color.adjust, 10), 
       xlim = c(1, l), ylim = range(analysis$t_compare), xaxt = "n", pch = 16, 
       xlab = "Number of Assets", ylab = "milliseconds", 
       main = paste(name, "5.Time Comparison", sep = ""))
  axis(1, at = seq(l), labels = label)
  lapply(2:l, function(x) 
    points(rep(x, 10 * k), as.vector(analysis$t_compare[[x]]), pch = 16,
           col = rep(color.adjust, 10)))
  
  lapply(1:k, function(k) lines(t_mean[k,], col = color[k]))
  
  legend("topleft", legend = c("cla", "qp", "cccp")[1:k], 
         col = color[1:k], pch = 16, lwd = 1)
  
  # 6. t_compare_log
  plot(rep(1, 10 * k), as.vector(analysis$t_compare[[1]]), 
       col = rep(color.adjust, 10),
       xlim = c(1, l), ylim = range(analysis$t_compare), xaxt = "n", pch = 16, 
       xlab = "Number of Assets", ylab = "milliseconds", 
       main = paste(name, "6. Log-Time Comparison", sep = ""), log = "y")
  axis(1, at = seq(l), labels = label)
  lapply(2:l, function(x) 
    points(rep(x, 10 * k), as.vector(analysis$t_compare[[x]]), pch = 16,
           col = rep(color.adjust, 10)))
  
  lapply(1:k, function(k) lines(t_mean[k,], col = color[k]))
  
  legend("topleft", legend = c("cla", "qp", "cccp")[1:k], 
         col = color, pch = 16, lwd = 1)
 dev.off()
  path <- gsub("/", "\\\\", d.file(paste(name, "_plot.pdf", sep = ""), exists = FALSE), 
               perl=TRUE)
  #ie. "D:\\Master Thesis\\Codes\\Data\\123456.pdf"
  system(paste0('open "', path, '"'))
}


time_lm <- function(analysis, n, vector.predict){ # vector to fit
  l <- length(exp_ind(1.2, 50, n)$ind)
  label <- exp_ind(1.2, 50, n)$ind
  t.mean.log <- log(sapply(seq(l), 
                           function(x) apply(analysis$t_compare[[x]], 1, mean)))
  k <- nrow(t.mean.log)
  x <- seq(l)
  fit <- lapply(1:k, function(i) lm(t.mean.log[i, ] ~ x ))
  names(fit) <- c("cla", "qp", "cccp")[1:k]
  new <- data.frame(x = vector.predict)
  p <- sapply(1:k, function(x) predict.lm(fit[[x]], new, se.fit = TRUE)$fit)
  if(is.matrix(p)){ 
    colnames(p) <- c("cla", "qp", "cccp")[1:k]
    rownames(p) <- vector.predict
  }else{names(p) <- c("cla", "qp", "cccp")[1:k]}
  list(fit = fit, predict = p)
}


plot_fit <- function(fit.list, analysis, name, n, n.predict){
  pdf(d.file(paste(name, "_lmplot.pdf", sep = ""), exists = FALSE)) 
  l <- length(exp_ind(1.2, 50, n)$ind)
  label <- exp_ind(1.2, 50, n)$ind
  t.mean.log <- log(sapply(seq(l), 
                           function(x) apply(analysis$t_compare[[x]], 1, mean)))
  k <- nrow(t.mean.log)
  ## 1.
  plot(c(1,l), range(t.mean.log), xaxt = "n", col = "green", pch = 16, 
       type = "n", xlab = "number of assets", ylab = "log(milliseconds)",
       main = paste(name, ":linear models of computation time"))
  axis(1, at = seq(l), labels = label)
  
  color <- c("red", "blue", "green")[1:k]
  lapply(1:k, function(x) {points(seq(l), t.mean.log[x,], col = color[x], pch = 16)
    abline(fit.list[[x]], col = color[x])})
  legend("topleft", legend = c("cla", "qp", "cccp")[1:k], 
         col = color[1:k],  pch = 16, lwd = 1)
  
  l.predict <- length(exp_ind(1.2, 50, n.predict)$ind)
  label.predict <- exp_ind(1.2, 50, n.predict)$ind
  
  pf <- function(k){
    fit <- fit.list[[k]]
    new <- data.frame(x = seq.int(l.predict))
    predict.lm(fit, new, se.fit = TRUE) 
    pred.pi <- predict.lm(fit, new, interval = "prediction")
    pred.ci <- predict.lm(fit, new, interval = "confidence")
    matplot(new$x, exp(cbind(pred.ci, pred.pi[,-1])),
            lty = 1, type = "l", ylab = "predicted y",
            xaxt = "n", xlab ="number of assets", 
            col = c("black", "blue", "blue", "red", "red"),
            main = paste(name, ":regression analysis of", names(fit.list)[k]))
    
    axis(1, at = seq(label.predict), labels = label.predict)
    legend("topleft", legend = c("confidence interval", "prediction interval"),
           col = c("blue", "red"), lty = 1)
  }
  lapply(1:k, pf)
  ##
  new <- data.frame(x = seq.int(l.predict))
  pm <- sapply(1:k, function(x) predict.lm(fit.list[[x]], new, se.fit = TRUE)$fit)
  color <- c("blue", "red", "green")
  plot(pm[,1], type = "l", ylim = range(pm), col = color[1],
       xlab = "number of assets", ylab = "log(milliseconds)" ,
       main = "prediction", xaxt = "n")
  axis(1, at = seq(label.predict), labels = label.predict)
  lapply(2:k, function(x) lines(pm[,x], 
                                type = "l", col = color[x]))
  legend("topleft", legend = c("cla", "qp", "cccp"), col = color, lwd = 1)
  dev.off()
  path <- gsub("/", "\\\\", d.file(paste(name, "_lmplot.pdf", sep = ""), exists = FALSE), 
               perl=TRUE)
  system(paste0('open "', path, '"'))
}

