if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
#############################################################################
Ver.info #view version information
verind

# Example: the first 20 assets
assets20 <- GetIndex(1:20, assets1457)
assets50 <- GetIndex(1:50, assets1457)
result20.list <- lapply(CLA, function(fun) 
          fun(assets20$mu, assets20$covar, assets20$lB, assets20$uB))
result50.list <- lapply(CLA, function(fun) 
  fun(assets50$mu, assets50$covar, assets50$lB, assets50$uB))

############################################################################
# PurgeNumErr (Ver 1.1 & Ver 1.3)
all.equal(cla.result.list$M1.2$weights_set, cla.result.list$M2$weights_set)
testPurgeNumErr <- function(result, lB, uB, ver.ind){
  free_indices <- result$free_indices
  gammas <- result$gammas
  lambdas <- result$lambdas
  weights_set <- result$weights_set
  old <- Env1.2$purgeNumErr(free_indices, gammas, lambdas, 
                            lB, uB, weights_set, 1e-09)[[3]]
  new <- Env2$purgeNumErr(lB = lB, uB = uB, weights_set = weights_set, 
                          tol.s = 1e-09, tol.b = 1e-10)
  list(new = new, old = old)
}
#lB, uB, solution_set, 
#tol.s, tol.b
r <- testPurgeNumErr(result = result20.list$M2, lB = assets20$lB, uB = assets20$uB)
testPurgeNumErr(result = result50.list$M2, lB = assets50$lB, uB = assets50$uB)





all.equal(Env1.2$cla.solver(assets$mu, assets$covar, assets$lB, assets$uB),
          cla.result.list[[3]])


###########################

w <- addW(uniqueW(r3$weights_set))
w[,purgeChull(w, mu, covar)]



addW(r3$weights_set)

adw<-addW(r3$weights_set_purge)$weights_set_new
adwn <- adw[,purgeChull(adw, mu, covar)]

rr <- lapply(1:ncol(adwn), function(x)(
  which( !(abs(adwn[,x]-1e-8)< 1e-10| abs(adwn[,x]- 0.075)<1e-10))
))

dif <- sapply(1:(ncol(adwn)-1), function(x) 
  all.equal(rr[[x+1]],rr[[x]])==TRUE)
dif
which(dif) # 4 7 10 13
h <- c()
for(j in which(dif)){
  ms <- MS(adwn[,(j-1):(j+2)], mu, covar)
  # test jth
  h1 <- hyperbolic(mu_in = ms[2,3], adwn[,j-1],adwn[,j+1], mu, covar  )-ms[2,2]# >0
  h2 <- hyperbolic(mu_in = ms[3,3], adwn[,j],adwn[,j+2], mu, covar  )-ms[3,2] # >0
  h <- c(h,h1,h2)
}

j-1
j #same
j+1 #same
j+2 

