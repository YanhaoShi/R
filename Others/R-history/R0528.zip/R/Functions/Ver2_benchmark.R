Method2 <-list( 
  # Initialize the weight -- Find first free weight
  initAlgo = (initAlgo = function(mu, lB, uB ){
    #New-ordered return, lB, uB with decreasing return  
    w <- c()
    index.new <- order(mu,decreasing = T) # new order with decreasing return
    lB.new <- lB[index.new]
    uB.new <- uB[index.new]
    # free weight - starting solution
    i.new <- 0
    w.new <- lB.new # initialy
    while(sum(w.new) < 1) {
      i.new <- i.new + 1
      w.new[i.new] <- uB.new[i.new]
    }
    w.new[i.new] <- 1 - sum(w.new[-i.new])
    w[index.new] <- w.new                #back to original order
    i<-index.new[i.new] 
    list(index=i,weights=w)         # return the index of first free asset and vector w
  }), 
  
  # getB1 ---  --------------------------------------------------------------------
  getB = (getB = function(mean,f) (1:length(mean))[-f]),
  
  # reduceMatrix ---  ------------------------------------------------------------
  reduceMatrix = (reduceMatrix = function(input, X, Y){
    if  (is.vector(input)){
      return(input[X])
    }
    else { return(input[X,Y,drop=F])}     
  }),
  
  
  # getMinVar ---  ---------------------------------------------------------------
  # Get the minimum variance solution
  getMinVar = (getMinVar = function(covar,solution_set1){          ## getMinStd !
    n<-ncol(solution_set1)
    var <- rep(1,n)
    for(i in 1:n){
      w<-solution_set1[,i]
      var[i] <- t(w) %*% covar %*% w
    }
    
    list(index_minvar= sqrt(min(var)), weights_minvar=solution_set1[ ,which.min(var)] )
  }), 
  
  # efFrontier -----------------------------------------------------------------
  # Get the efficient frontier
  efFrontier = (efFrontier = function(mean, covar, solution_set, dataPoints){ 
    n<-ncol(solution_set)
    mu <- c()
    sigma <- c()
    weights <- c()
    a <- seq(0,1,length=dataPoints+1)[-1]  #dataPoints-2 in between
    
    for(i in 1:(n-1)){
      
      w0 <- solution_set[,i]
      w1 <- solution_set[,i+1]
      
      w <- w0 %*% t(a) + w1 %*% t(1-a)   #weights between
      weights <- cbind(weights,w)
    }
    weights <- cbind(weights, solution_set[,n])
    mu <- t(mean) %*% weights
    
    sigma <- apply(weights, 2, function(x) sqrt(t(x) %*% covar %*% x))
    
    return(list(mu = mu, weights = weights, sigma = sigma))
  }),  
  
  # computeW -----------------------------------------------------------------
  # compute gamma #(Bailey and Lopez de Prado 2013, 11)
  computeW = (computeW = function(lambdas,covarFB,meanF,wB, covarF){
    #1) compute gamma
    s2 <- solve(covarF, meanF)
    g1 <- sum(s2)  
    g2 <- sum(solve(covarF))
    l.tail <- lambdas[length(lambdas)]
    if(is.null(wB)){
      g <- as.numeric(-l.tail*g1/g2+1/g2) 
      w1 <- 0
    } else {
      g3 <- sum(wB)
      w1 <- solve(covarF, covarFB %*% wB)
      g4 <- sum(w1)
      g <- as.numeric(-l.tail*g1/g2+(1-g3+g4)/g2)
    }
    #2) compute weights
    w2 <- solve(covarF,matrix(1,length(meanF)))
    w3 <- s2
    list(wF = -w1+g*w2+l.tail*w3, gamma = g)
  }),
  
  # computeLambda --------------------------------------------------------------
  # (Niedermayer and Niedermayer 2007, 10)
  computeLambda = (computeLambda = function(covarFB, meanF, wB, i, bi, covarF){
    #1) C
    onesF <- matrix(1,length(meanF)) # (kx1)-vector
    s1 <- solve(covarF, onesF)
    s2 <- solve(covarF, meanF)
    c1 <- sum(s1)
    c2i <-  s2[i]
    c3 <- sum(s2)
    c4i <- s1[i]
    cc <- -c1*c2i + c3*c4i  
    if(cc == 0){
      return(list(lambda = 0,bi = 0))
    }
    #2) bi
    if(is.list(bi)){
      
      bi <- ifelse(cc > 0, bi[[2]], bi[[1]])
    }
    #3) lambda
    if(length(wB)==0){
      # All free assets
      return(list(lambda = (c4i - c1 * bi)/cc,bi = bi))
    }else{
      l1 <- sum(wB)
      l3 <- solve(covarF, covarFB %*% wB)
      l2 <- sum(l3)
      return(list(lambda = ((1-l1+l2)*c4i-c1*(bi+l3[i]))/cc, bi = bi))
    }
  }),
  
  # getMatrices --- -------------------------------------------------------------
  getMatrices = (getMatrices = function(mean, covar, solution_set, f){
    # Slice covarF,covarFB,covarB,meanF,meanB,wF,wB
    covarF <- covar[f,f]
    meanF <- mean[f]
    b <- (1:length(mean))[-f]
    covarFB <- covar[f,b]
    wB <- solution_set[,ncol(solution_set)][b] 
    return(list(covarF=covarF,covarFB=covarFB,meanF=meanF,wB=wB))
  }),
  
  # purgeNumErr ---  -------------------------------------------------------------
  # Purge violations: remove w if sum(w)!=1, w<lB, w>uB
  purgeNummErr = (purgeNummErr = function(lB, uB, solution_set, 
                                          tol.s, tol.b){ 
    n <- ncol(solution_set)
    i.s <- which(abs(colSums(solution_set)-1) > tol.s)
    m_lB <- matrix(rep(lB, n), ncol = n)
    m_uB <- matrix(rep(uB, n), ncol = n) 
    m_logical <- (solution_set - m_lB < -tol.b) | (solution_set - m_uB > tol.b)
    i.b <- which(apply(m_logical, 2, any))
    c(i.s, i.b, n+1)
  }), 
  
  # purgeExcess ---   -------------------------------------------------------------
  # Remove violations of the convex hull, ensure mu2>mu3, ...
  purgeExcess = (purgeExcess = function(mean, solution_set, tol){ 
    n <- ncol(solution_set)
    mu <- t(mean) %*% solution_set
    c(which( (mu[2:(n-1)] - mu[3:n]) < -tol ), n+1 )  
  }),
  
  ## combined in one purge function
  purge = (purge = function(mean, lB, uB, solution_set, 
                            tol.s, tol.b, tol){ 
    n <- ncol(solution_set)
    i.s <- which(abs(colSums(solution_set)-1) > tol.s)
    m_lB <- matrix(rep(lB, n), ncol = n)
    m_uB <- matrix(rep(uB, n), ncol = n) 
    m_logical <- (solution_set - m_lB < -tol.b) | (solution_set - m_uB > tol.b)
    i.b <- which(apply(m_logical, 2, any))
    i.un <- c(i.s, i.b, n+1)
    
    solution_set <- solution_set[,-i.un]
    n <- ncol(solution_set)
    mu <- t(mean) %*% solution_set
    i.ex <- which( (mu[2:(n-1)] - mu[3:n]) < -tol )
    list(i.un = i.un, i.ex = i.ex, i = c(i.un, i.ex))
  }),
  
  ## convex hull
  purgeChull = (purgeChull <- function(solution_set, mean, covar){
    Sig2 <- colSums(solution_set *(covar %*% solution_set) )
    Mu <- t(solution_set) %*% mean
    ch <- sort(chull(cbind(Sig2, Mu)))
    index.chull <- ch[Sig2[ch] <= Sig2[which.max(Mu)]]
    index.chull
  }),
  
  cla.solver = function(mean, covar,lB, uB){                                             
    # Compute the turning points,free sets and weights
    f <- initAlgo(mean, lB, uB)$index
    w <- as.matrix(initAlgo(mean, lB, uB)$weights)
    solution_set <- w # store solution
    lambdas <-  c()
    gammas <- c()
    free_weights <- list(f) ### 
    list_temp <- c() 
    while ( TRUE ) {
      # 1) case a): Bound one free weight 
      l_in <- 0
      temp_getMat1 <- getMatrices(mean, covar,solution_set, f)
      covarF1 <- temp_getMat1$covarF
      covarFB1 <- temp_getMat1$covarFB
      meanF1 <- temp_getMat1$meanF
      wB1 <- temp_getMat1$wB
      if(length(f) > 1){  
        j <- 1
        for (i1 in f) {
          temp_compLam <- computeLambda(covarFB1,meanF1,wB1,j,
                                        as.list(c(lB[i1],uB[i1])),covarF1)
          l1 <- temp_compLam$lambda 
          bi <- temp_compLam$bi 
          if( l1 > l_in  ){  
            l_in <- l1
            i_in <- i1
            bi_in <- bi   
          }
          j <- j + 1
        }
      }  
      # 2) case b): Free one bounded weight
      l_out <- 0
      if(length(f) < length(mean)) {
        
        b <- (1:length(mean))[-f]
        for(i in b){
          temp_getMat2 <- getMatrices(mean, covar,solution_set, c(f,i))
          covarF2 <- temp_getMat2$covarF
          covarFB2 <- temp_getMat2$covarFB
          meanF2 <- temp_getMat2$meanF
          wB2 <- temp_getMat2$wB
          temp_compLam <- computeLambda(covarFB2,meanF2,wB2,length(meanF2),
                                        solution_set[i,ncol(solution_set)],covarF2)
          l2 <- temp_compLam$lambda 
          bi <- temp_compLam$bi
          
          if ((length(lambdas)==0 || l2<lambdas[length(lambdas)]) && (l2>l_out)){
            l_out <- l2
            i_out <- i
            temp_getMat_out <- temp_getMat2
          }
        }
      }
      
      if( (l_in <= 0) & (l_out <= 0) ) { # "stop" when at the min var solution! 
        
        # 3) compute minimum variance solution
        lambdas <- c(lambdas,0)
        meanF <- matrix(0,length(meanF))
        temp_compW <- computeW(lambdas,covarFB1,meanF,wB1,covarF1)
        wF <- temp_compW$wF
        g <- temp_compW$gamma
        
        list_temp <- c(list_temp, list(temp_getMat1))
        
        for(i in seq(length(f))){
          w[f[i]]=wF[i]
        }
        solution_set <- cbind(solution_set, w) # store solution
        gammas <- c(gammas, g)
        break
        
      } else {
        
        # 4) decide lambda       
        if(l_in>l_out){ 
          lambdas <- c(lambdas,l_in)
          f <- f[f != i_in] # remove i_in within f
          w[i_in] = bi_in # set value at the correct boundary
          temp_getMat1 <- getMatrices(mean, covar,solution_set, f)
          covarF <- temp_getMat1$covarF
          covarFB <- temp_getMat1$covarFB
          meanF <- temp_getMat1$meanF
          wB <- temp_getMat1$wB
          temp_compW <- computeW(lambdas,covarFB,meanF,wB,covarF)
          wF <- temp_compW$wF
          g <- temp_compW$gamma 
          
          
        }else{
          lambdas <- c(lambdas,l_out)
          f <- c(f,i_out) # append i_out into f
          
          temp_getMat1 <- temp_getMat_out
          covarF <- temp_getMat1$covarF
          covarFB <- temp_getMat1$covarFB
          meanF <- temp_getMat1$meanF
          wB <- temp_getMat1$wB
          temp_compW <- computeW(lambdas,covarFB,meanF,wB,covarF)
          wF <- temp_compW$wF
          g <- temp_compW$gamma
        }
        
        
        for(i in seq(length(f))){
          w[f[i]]=wF[i]
        }
        
        solution_set <- cbind(solution_set, w) # store solution
        gammas <- c(gammas, g)
        free_weights <- c(free_weights, list(f))
        
      }
      
    } #end While  
    lambdas <- c(NA, lambdas) #The first step has no lambda or gamma, add NA instead
    gammas <- c(NA, gammas)
    free_weights <- c(free_weights, NA) # The last step stop without weight set, add NA.
    
    i <- purgeNummErr(lB, uB, solution_set, 1e-9, 1e-10) 
    solution_set <- solution_set[,-i]
    lambdas <- lambdas[-i]
    gammas <- gammas[-i]
    free_weights <- free_weights[-i]
    
    k <- purgeChull(solution_set, mean, covar)
    solution_set <- solution_set[,k] 
    lambdas <- lambdas[k] 
    gammas <- gammas[k]
    free_weights <- free_weights[k]
    
    list(solution_set = solution_set, free_indices=free_weights, 
         gammas = gammas, lambdas = lambdas)
    
  },
  
  cla.solver.unpurge = function(mean, covar,lB, uB){                                             
    # Compute the turning points,free sets and weights
    f <- initAlgo(mean, lB, uB)$index
    w <- as.matrix(initAlgo(mean, lB, uB)$weights)
    solution_set <- w # store solution
    lambdas <-  c()
    gammas <- c()
    free_weights <- list(f) ### 
    list_temp <- c() 
    while ( TRUE ) {
      # 1) case a): Bound one free weight 
      l_in <- 0
      temp_getMat1 <- getMatrices(mean, covar,solution_set, f)
      covarF1 <- temp_getMat1$covarF
      covarFB1 <- temp_getMat1$covarFB
      meanF1 <- temp_getMat1$meanF
      wB1 <- temp_getMat1$wB
      if(length(f) > 1){  
        j <- 1
        for (i1 in f) {
          temp_compLam <- computeLambda(covarFB1,meanF1,wB1,j,
                                        as.list(c(lB[i1],uB[i1])),covarF1)
          l1 <- temp_compLam$lambda 
          bi <- temp_compLam$bi 
          if( l1 > l_in  ){  
            l_in <- l1
            i_in <- i1
            bi_in <- bi   
          }
          j <- j + 1
        }
      }  
      # 2) case b): Free one bounded weight
      l_out <- 0
      if(length(f) < length(mean)) {
        
        b <- (1:length(mean))[-f]
        for(i in b){
          temp_getMat2 <- getMatrices(mean, covar,solution_set, c(f,i))
          covarF2 <- temp_getMat2$covarF
          covarFB2 <- temp_getMat2$covarFB
          meanF2 <- temp_getMat2$meanF
          wB2 <- temp_getMat2$wB
          temp_compLam <- computeLambda(covarFB2,meanF2,wB2,length(meanF2),
                                        solution_set[i,ncol(solution_set)],covarF2)
          l2 <- temp_compLam$lambda 
          bi <- temp_compLam$bi
          
          if ((length(lambdas)==0 || l2<lambdas[length(lambdas)]) && (l2>l_out)){
            l_out <- l2
            i_out <- i
            temp_getMat_out <- temp_getMat2
          }
        }
      }
      
      if( (l_in <= 0) & (l_out <= 0) ) { # "stop" when at the min var solution! 
        
        # 3) compute minimum variance solution
        lambdas <- c(lambdas,0)
        meanF <- matrix(0,length(meanF))
        temp_compW <- computeW(lambdas,covarFB1,meanF,wB1,covarF1)
        wF <- temp_compW$wF
        g <- temp_compW$gamma
        
        list_temp <- c(list_temp, list(temp_getMat1))
        
        for(i in seq(length(f))){
          w[f[i]]=wF[i]
        }
        solution_set <- cbind(solution_set, w) # store solution
        gammas <- c(gammas, g)
        break
        
      } else {
        
        # 4) decide lambda       
        if(l_in>l_out){ 
          lambdas <- c(lambdas,l_in)
          f <- f[f != i_in] # remove i_in within f
          w[i_in] = bi_in # set value at the correct boundary
          temp_getMat1 <- getMatrices(mean, covar,solution_set, f)
          covarF <- temp_getMat1$covarF
          covarFB <- temp_getMat1$covarFB
          meanF <- temp_getMat1$meanF
          wB <- temp_getMat1$wB
          temp_compW <- computeW(lambdas,covarFB,meanF,wB,covarF)
          wF <- temp_compW$wF
          g <- temp_compW$gamma 
          
          
        }else{
          lambdas <- c(lambdas,l_out)
          f <- c(f,i_out) # append i_out into f
          
          temp_getMat1 <- temp_getMat_out
          covarF <- temp_getMat1$covarF
          covarFB <- temp_getMat1$covarFB
          meanF <- temp_getMat1$meanF
          wB <- temp_getMat1$wB
          temp_compW <- computeW(lambdas,covarFB,meanF,wB,covarF)
          wF <- temp_compW$wF
          g <- temp_compW$gamma
        }
        
        
        for(i in seq(length(f))){
          w[f[i]]=wF[i]
        }
        
        solution_set <- cbind(solution_set, w) # store solution
        gammas <- c(gammas, g)
        free_weights <- c(free_weights, list(f))
        
      }
      
    } #end While  
    lambdas <- c(NA, lambdas) #The first step has no lambda or gamma, add NA instead
    gammas <- c(NA, gammas)
    free_weights <- c(free_weights, NA) # The last step stop without weight set, add NA.
    list(solution_set = solution_set, free_indices=free_weights, 
         gammas = gammas, lambdas = lambdas)
    
  }
)