MS <- function(solution_set, mu, covar){
  Sig2 <- colSums(solution_set *(covar %*% solution_set) )
  cbind(Sig = sqrt(Sig2), Sig2 = Sig2, Mu = as.vector(t(solution_set) %*% mu))
}

MS_plot <- function(ms, col = "blue"){  #list of solution_set, legend...
  plot(ms[,"Sig2"], ms[,"Mu"], type = "o", pch = 16, col = adjustcolor(col, alpha.f = 0.5),
       main = "Efficient Frontier", xlab = expression(mu),
       ylab = expression(sigma^2))
}


w.compare <- function(mu, covar, lB, uB){  #as.matrix(lB or uB)!
  micro <- microbenchmark( result.cla <- CLA$M3(mu, covar, lB, uB),
                           w.qp <- lapply(((0:ncol(result.cla$weights_set_purge))/ncol(result.cla$weights_set_purge))^2, function(x) 
                             return(tryCatch(QP.solve(mu, covar, lB, uB,x),  # skip error, pick "correct" mu
                                             error=function(e) NULL))),
                           w.cccp <- sapply(MS(result.cla$weights_set_purge, mu, covar)[,"Sig"], function(x) CCCP.solve (covar, mu, x,  
                                                                                                 lB, uB)),
                           times = 3)
  w.cla <- result.cla$weights_set_purge
  n <- ncol(w.cla)  # rescale density, for better plotting...
  lam <- ((0:n)/n)^2
  ind.qp <- which(!sapply(w.qp,is.null))
  w.qp <- sapply(ind.qp, function(x) w.qp[[x]]) # remove NULL terms
  w.cccp <- matrix(w.cccp[!is.na(w.cccp)], nrow = nrow(w.cccp))  # remove NaN
  
  
  
  list(weights = list(w.cla = w.cla, w.qp = w.qp, w.cccp = w.cccp),
       MS = list( ms.cla = MS(w.cla, mu, covar),
                  ms.qp = MS(w.qp, mu, covar),
                  ms.cccp = MS(w.cccp, mu, covar)),
       micro = micro, lambda.qp = lam[ind.qp], result.cla = result.cla)# compare micro?
}


Total.plot <- function(ms.list){
  MS_plot(ms.list[[1]])
  for (i in 2:length(ms.list)){
    points(ms.list[[i]][,"Sig2"], ms.list[[i]][,"Mu"] , pch = 16, col = adjustcolor(col = i, alpha.f = 0.5))
  }
  legend("bottomright", 
         legend = names(ms.list),
         lty = 1, col = sapply(1:3, function(x) adjustcolor(x, alpha.f = 0.5)))
} 

###########################################################################
CLA_results50 <- readRDS(d.file("CLA_results50.rds", exists = FALSE))
assets50 <- readRDS(d.file("assets50.rds", exists = FALSE))

weights.compare <- w.compare(assets50$mu, assets50$covar, 
                         assets50$lB, as.matrix(rep(1,50)))

weights.micro <- weights.compare$micro
weights.list <- weights.compare$weights
weights.MS <- weights.compare$MS

# time: QP < CLA << CCCP

Total.plot(weights.MS)
# under a given risk, the expected return of the point on CLA EF are 
# generally slightly higher than expected return on quadratic EF.
# hard to observe on EF plot.

# Portgr returns positive weights (slightly) larger than lB or
# (slightly) smaller than uB, but not on the bounds
# Portgr requires given risks, hard to know the range of given risks
# CLA returns bounded weights exactly on uB or lB, but not work for small number of assets


