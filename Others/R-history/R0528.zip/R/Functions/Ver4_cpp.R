initAlgo = function(mu, lB, uB ){
  #New-ordered return, lB, uB with decreasing return  
  w <- c()
  index.new <- order(mu,decreasing = T) # new order with decreasing return
  lB.new <- lB[index.new]
  uB.new <- uB[index.new]
  # free weight - starting solution
  i.new <- 0
  w.new <- lB.new # initialy
  while(sum(w.new) < 1) {
    i.new <- i.new + 1
    w.new[i.new] <- uB.new[i.new]
  }
  w.new[i.new] <- 1 - sum(w.new[-i.new])
  w[index.new] <- w.new                #back to original order
  i<-index.new[i.new] 
  list(index=i,weights=w)         # return the index of first free asset and vector w
}


cppFunction(List initAlgo1(double mu, double lB, double uB )){
  #New-ordered return, lB, uB with decreasing return  
  w <- c()
  index.new <- sort (mu,decreasing = T) # new order with decreasing return
  lB.new <- lB[index.new]
  uB.new <- uB[index.new]
  # free weight - starting solution
  i.new <- 0
  w.new <- lB.new # initialy
  while(sum(w.new) < 1) {
    i.new <- i.new + 1
    w.new[i.new] <- uB.new[i.new]
  }
  w.new[i.new] <- 1 - sum(w.new[-i.new])
  w[index.new] <- w.new                #back to original order
  i<-index.new[i.new] 
  list(index=i,weights=w)         # return the index of first free asset and vector w
}

