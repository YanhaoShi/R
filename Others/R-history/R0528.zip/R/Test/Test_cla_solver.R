if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
# Compare results
CLA_results <- function(ind, re = 10){  # re: repeat times # m: first m assets
  assets1457 <- readRDS(d.file("assets1457.rds", exists = FALSE))
  assets <- GetAssets(ind, assets1457)
  micro <- microbenchmark(
    r1 <- CLA$M1(assets$mu, assets$covar, assets$lB, assets$uB),
    r2 <- CLA$M2(assets$mu, assets$covar, assets$lB, assets$uB),
    r3 <- CLA$M3(assets$mu, assets$covar, assets$lB, assets$uB), times = re) 
  t <- unname(sapply(levels(micro$expr), 
                     function(x){median(micro$time[micro$expr==x])*1e-6}))
  list(r1 = r1, r2 = r2, r3 = r3,  # cla.solver results
       t = t)  # times: millionseconds
}

# x-axis index, including n!!!
fibonacci <- function(n){
  f <- 1:2
  for(i in 3:100){
    f[i] <- f[i-1] + f[i-2]
    if(f[i] > n) break
  }
  list(number_selected = i-1, fibonacci = f[-i])
}



#  save cla resulte(ver1, ver2, ver3) and cla time
if(file.exists(d.file("CLA_time.rds", exists = FALSE))){
  CLA_time <- readRDS(d.file("CLA_time.rds", exists = FALSE))
}else{
  CLA_time <- c()
}

fibonacci(1457)$fibonacci   #1450
for (m in c(50:120, seq(150,1450, 50) )){
  CLA_time <- readRDS(d.file("CLA_time.rds", exists = FALSE))
  if( !file.exists(d.file(paste("CLA_results", m, ".rds", sep = ""), exists = FALSE))){ 
  CLA_analysis<- CLA_results(1:m, re = 10)
  CLA_time <- rbind(CLA_time, CLA_analysis$t)
  saveRDS(CLA_analysis[1:3], d.file(paste("CLA_results", m, ".rds", sep = ""), 
                                    exists = FALSE))
  saveRDS(CLA_time, d.file("CLA_time.rds", exists = FALSE))
  }
}


row.names(CLA_time) <- c(50:120, seq(150, 1050, 50))

t <- CLA_time[c(1, 51, 72:90),]
nrow(t)
plot(1:21, t[,1], type = "l", pch = 16, xlab = "number of assets", ylab = "millionseconds")
title("Efficient Frontier for CLA")
lines(t[,2], col = "red")
lines(t[,3], col = "blue")
legend("topleft", legend = c("Ver1", "Ver2", "Ver3"), lwd = 1, col = c("black", "red", "blue"))



# corresponding index selected with fibonacci for company assets, each for 50 times
if(!file.exists(d.file("ind_company.rds", exists = FALSE))){
  n <- 1457         
  fi <- fibonacci(n)
  set.seed(2017)
  ind.list <- list()
  for(i in 1:fi$number_selected){
    ind.list[[i]] <- lapply(rep(fi$fibonacci[i], 50), function(x) sample(seq(n), x, replace = FALSE))
  }
  saveRDS(ind.list, d.file("ind_company.rds", exists = FALSE))
}
ind.list <- readRDS(d.file("ind_company.rds", exists = FALSE))  
#with length fibonacci(1457)$number, each sublist with 50 elements of corresponding length 




###
weights.compare <- w.compare(assets$mu, assets$covar, 
                             assets$lB, as.matrix(rep(1,50)))





# remove warning?
sapply(MS(result.cla$weights_set_purge, mu, covar)[,"Sig"], function(x) CCCP.solve (covar, mu, x,  
                                                                                    lB, uB))



























sessionInfo() # computing info
#######################################################################################
plot(x = 50:120, y = CLA_time[,1], col = "black", type = "l", pch = 16, 
     ylim = range(CLA_time), main = "Efficient Frontier of different CLA versions",
     xlab = "number of assets", ylab = "milliseconds")
points(50:120, CLA_time[,2], col = "red", type = "l", pch = 16)
points(50:120, CLA_time[,3], col = "blue", type = "l", pch = 16)
legend("topleft", legend = c("ver1", "ver2", "ver3"), 
       col = c("black", "red", "blue"), lty = 1)

# png(d.file("CLA_time_plot.png", exists = FALSE))    #how to dev.off() ???
# dev.off()
#########################################

kappa(assets50$covar)
ev <- eigen(assets_50$covar, only.values=TRUE)$values
plot(ev, log="y") #not too bad

r3 <-as.matrix(r_50[[3]])
ef <- efFrontier1(assets_50$mu, assets_50$covar, as.matrix(r_50[[3]]), 10)
ef1 <- efFrontier1(assets_50$mu, assets_50$covar, r2_50$solution_set,10)




 
