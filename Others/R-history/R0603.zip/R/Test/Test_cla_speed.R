assets1457 <- readRDS(d.file("assets1457.rds", exists = FALSE))

for (i in (1:14)*100){
  assets <- GetAssets(seq(i), assets1457) 
  micro[[i]] <- microbenchmark(CLA$M3(assets$mu, assets$covar, assets$lB, assets$uB),
                               CLA$M4(assets$mu, assets$covar, assets$lB, assets$uB),
                               times = 3)
}

assets50 <- readRDS(d.file("assets50.rds", exists = FALSE))
assets100 <- readRDS(d.file("assets100.rds", exists = FALSE))

microbenchmark(CLA$M2(assets50$mu, assets50$covar, assets50$lB, assets50$uB),
               CLA$M3(assets50$mu, assets50$covar, assets50$lB, assets50$uB),
               times = 3)

microbenchmark(CLA$M2(assets100$mu, assets100$covar, assets100$lB, assets100$uB),
               CLA$M3(assets100$mu, assets100$covar, assets100$lB, assets100$uB),
               times = 3)

all.equal(CLA$M2(assets50$mu, assets50$covar, assets50$lB, assets50$uB),
          CLA$M3(assets50$mu, assets50$covar, assets50$lB, assets50$uB))

all.equal(CLA$M3(assets100$mu, assets100$covar, assets100$lB, assets100$uB),
          CLA$M4(assets100$mu, assets100$covar, assets100$lB, assets100$uB))

microbenchmark(tail(1:1000,1), (1:1000)[length(1:1000)])
microbenchmark(f1(1000), f2(1000) )
f1<-function(x) {
  u = as.numeric()
  for(i in 1:1000) u[i] = i
  u
}
f2<-function(x){
  u =c()
  for(i in 1:1000) u[i] = i
u}
x <- 1:3
x[]=1
