 

for(i in 1:length(ind.list)){#length(ind.list)
  for(j in 1:10){
    if( !file.exists(d.file(paste("assets", i, "_set", j, sep = ""), exists = FALSE))){ 
      ind <- ind.list[[i]][[j]]
      assets <- GetAssets(ind, assets1457)
      weights.compare <- w.compare(assets$mu, assets$covar, 
                                   assets$lB, assets$uB)
      saveRDS(weights.compare, d.file(paste("assets", i, "_set", j, sep = ""), exists = FALSE)) 
      #assetsi_setj: i assets in total, with jth indices set 
    }
  }
}


# plot number of weights
for(i in 1:8){
  for (j in 1:10){ #recent  rds missing!!!
    assign(paste("assets", i, "_set", j, sep = ""),readRDS(d.file(paste("assets", i, "_set", j, sep = ""), exists = FALSE)))
  }
}
Total.plot(assets8_set3$MS)

cla.list <- list()
t_compare <- list()
nweights <- matrix(0, ncol = 8, nrow = 10)
nweights_unpurge <- matrix(0, ncol = 8, nrow = 10)
cov.kappa <- matrix(0, ncol = 8, nrow = 10)
cov.rcond <- matrix(0, ncol = 8, nrow = 10)
covF <- list() # 8 sub-list, each with 10 sub-list, with cla-result of covFs
for(i in 1:8){
  re <- lapply(1:10, function(x)
    readRDS(d.file(paste("assets", i, "_set", x, sep = ""), 
                   exists = FALSE)))
  
    
  cla.list[[i]] <- lapply(1:10, function(x)re[[x]]$result.cla)
  
  t_compare[[i]] <- sapply(1:10, function(x) {micro <- re[[x]]$micro
           unname(sapply(levels(micro$expr), 
                function(y){median(micro$time[micro$expr==y])*1e-6}))})
  
  nweights[, i] <- sapply(1:10, function(x) ncol(cla.list[[i]][[x]]$weights_set_purge))
  nweights_unpurge[,i] <- sapply(1:10, function(x) ncol(cla.list[[i]][[x]]$weights_set))
  
  covF[[i]] <- lapply(1:10, function(x) lapply(cla.list[[i]][[x]]$covarF, as.matrix))
  cov.kappa[, i] <- sapply(1:10,function(x) max(sapply(covF[[i]][[x]], kappa)))
  cov.rcond[, i] <- sapply(1:10,function(x) min(sapply(covF[[i]][[x]], rcond)))
}

## draft here

m <- covF[[2]][[1]][[22]]
kappa(m)

rcond(m)
plot(cov.kappa, type = "o", main = "kappa")


cov.m <- lapply(cf, as.matrix)
sapply(m, rcond)
lapply(cov.m, nearPD)



# nweights_ind_boxplot
nweights
boxplot(nweights, xlab = "Number of Assets", ylab = "Number", 
        main = "Number of Weights Sets", xaxt = "n")
axis(1, at = 1:8,labels = exp_ind(1.2, 50, 1457)$ind[1:8] )

# nweights_ind_plot
plot(apply(nweights, 2, mean), ylim = range(c(nweights, nweights_unpurge)), pch = 16, col = "red",
     xlab = "Number of Assets", ylab = "Number", type = "o",
     main = "Number of Weights Sets", xaxt = "n")
axis(1, at = 1:8,labels = exp_ind(1.2, 50, 1457)$ind[1:8] )
lapply(1:10, function(x) points(nweights[x,], pch = 16, col = adjustcolor("blue", 0.5)))
lapply(1:10, function(x) points(nweights_unpurge[x,], pch = 16, col = adjustcolor("yellow", 0.5)))
legend("topleft", legend = c("mean-purge", "purge", "unpurge"), 
       col = c("red", "blue", "yellow"), lwd = 1, pch =16)

# kappa
boxplot(cov.kappa, xlab = "Number of Assets", ylab = "kappa", 
        main = "Max-kappa of CovF", xaxt = "n")
axis(1, at = 1:8,labels = exp_ind(1.2, 50, 1457)$ind[1:8] )

# rcond
boxplot(cov.rcond, xlab = "Number of Assets", ylab = "rcond", 
        main = "Min-rcond of CovF", xaxt = "n")
axis(1, at = 1:8,labels = exp_ind(1.2, 50, 1457)$ind[1:8] )

# t_compare
t_mean <- sapply(1:8, function(x) apply(t_compare[[x]], 1, mean))
plot(rep(1,30), as.vector(t_compare[[1]]), 
     col = rep(c(adjustcolor("red", 0.3), adjustcolor("blue", 0.3), 
                 adjustcolor("green", 0.3)), 10, each = TRUE), 
     xlim = c(1, 8), ylim = range(t_compare), xaxt = "n", pch = 16, 
     xlab = "Number of Assets", ylab = "milliseconds", main = "Time Comparison")
axis(1, at = 1:8,labels = exp_ind(1.2, 50, 1457)$ind[1:8] )
lapply(2:8, function(x) 
  points(rep(x,30), as.vector(t_compare[[x]]), pch = 16,
         col = rep(c(adjustcolor("red", 0.3), adjustcolor("blue", 0.3), 
                     adjustcolor("green", 0.3)), 10, each = TRUE)))
lines(t_mean[1,], col = adjustcolor("red", 0.5))
lines(t_mean[2,], col = adjustcolor("blue", 0.5))
lines(t_mean[3,], col = adjustcolor("green", 0.5))
legend("topleft", legend = c("cla", "qp", "cccp"), col = c("red", "blue", "green"), 
       pch = 16)

# t_compare_cla_qp
plot(1:8, t_mean[1,], type = "o", ylim = range(t_mean[-3,]), col = "red", 
     pch = 16, xaxt = "n", xlab = "Number of Assets", 
     ylab = "millionseconds", main = "Time Comparison of CLA and QP")
lines(1:8, t_mean[2,], col = "blue", pch = 16, type = "o")
axis(1, at = 1:8,labels = exp_ind(1.2, 50, 1457)$ind[1:8] )
legend("topleft", legend = c("cla", "qp"), col = c("red", "blue"), lwd = 1, pch = 16)

# qp method is faster than cla when the number of assets is small, 
# but much slower when number of assets is larger 



