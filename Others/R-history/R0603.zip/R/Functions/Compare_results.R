# Compare results

# compare 3 versions of CLA time and results
CLA_results <- function(ind, re = 10){  # re: repeat times # m: first m assets
  assets1457 <- readRDS(d.file("assets1457.rds", exists = FALSE))
  assets <- GetAssets(ind, assets1457)
  micro <- microbenchmark(
    r1 <- CLA$M1(assets$mu, assets$covar, assets$lB, assets$uB),
    r2 <- CLA$M2(assets$mu, assets$covar, assets$lB, assets$uB),
    times = re) 
  t <- unname(sapply(levels(micro$expr), 
                     function(x){median(micro$time[micro$expr==x])*1e-6}))
  list(r1 = r1, r2 = r2,  # cla.solver results
       t = t)  # times: millionseconds
}


# x-axis scaled index
exp_ind <- function(x, start, end){
  a <- ceiling(log(start)/log(x) )
  b <- floor(log(end)/log(x))
  list(power = a:b, ind = round(x^(a:b)))
}