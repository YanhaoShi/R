MS <- function(solution_set, mu, covar){
  Sig2 <- colSums(solution_set *(covar %*% solution_set) )
  cbind(Sig = sqrt(Sig2), Sig2 = Sig2, Mu = as.vector(t(solution_set) %*% mu))
}

MS_plot <- function(ms, col = "blue"){  #list of solution_set, legend...
  plot(ms[,"Sig2"], ms[,"Mu"], type = "o", pch = 16, col = adjustcolor(col, alpha.f = 0.5),
       main = "Efficient Frontier", xlab = expression(mu),
       ylab = expression(sigma^2))
}


w.compare <- function(mu, covar, lB, uB){  #as.matrix(lB or uB)!
  w.cla <- CLA$M3(mu, covar, lB, uB)$weights_set_purge
  n <- ncol(w.cla)  # rescale density, for better plotting...
  micro <- microbenchmark( cla = result.cla <- CLA$M3(mu, covar, lB, uB),
                           qp = w.qp <- lapply(((0:n)/n)^2, 
                                               function(x) return(tryCatch(QP.solve(mu, covar, lB, uB,x), # skip error, pick "correct" mu
                                                                           error=function(e) NULL))),
                           cccp = w.cccp <- sapply(MS(w.cla, mu, covar)[,"Sig"], 
                                                   function(x) CCCP.solve (covar, mu, x, lB, uB)),
                           times = 3)
  
  
  lam <- ((0:n)/n)^2
  ind.qp <- which(!sapply(w.qp,is.null))
  w.qp <- sapply(ind.qp, function(x) w.qp[[x]]) # remove NULL terms
  w.cccp <- matrix(w.cccp[!is.na(w.cccp)], nrow = nrow(w.cccp))  # remove NaN

  list(weights = list(w.cla = w.cla, w.qp = w.qp, w.cccp = w.cccp),
       MS = list( ms.cla = MS(w.cla, mu, covar),
                  ms.qp = MS(w.qp, mu, covar),
                  ms.cccp = MS(w.cccp, mu, covar)),
       micro = micro, lambda.qp = lam[ind.qp], result.cla = result.cla)# compare micro?
}



Total.plot <- function(ms.list){
  MS_plot(ms.list[[1]])
  for (i in 2:length(ms.list)){
    points(ms.list[[i]][,"Sig2"], ms.list[[i]][,"Mu"] , pch = 16, col = adjustcolor(col = i, alpha.f = 0.5))
  }
  legend("bottomright", 
         legend = names(ms.list),
         lty = 1, col = sapply(1:3, function(x) adjustcolor(x, alpha.f = 0.5)))
} 


# piecewise hyperbolic on Efficient Frontier
hyperbolic <- function(mu_in, w1, w2, Mu, Cov){  
  mu1 <- sum(Mu * w1)   # mu1 > mu2
  mu2 <- sum(Mu * w2)
  lambda <- (mu_in - mu1)/(mu2 - mu1)
  w_in <- (1-lambda)*w1 + lambda*w2
  sum(w_in * (Cov %*% w_in))  # sig2 of mu_in
}

compareEF <- function(w.qp, w.cla, Mu, Cov){
  ms.qp <- MS(w.qp, Mu, Cov)
  ms.cla <- MS(w.cla, Mu, Cov)
  ind <- (ms.qp[, "Mu"] <= max(ms.cla[, "Mu"]))&(ms.qp[, "Mu"] >= min(ms.cla[, "Mu"]))
  Sig2.cla <- sapply(which(ind), function(i){j <- sum(ms.cla[, "Mu"] > ms.qp[i, "Mu"])
  hyperbolic(ms.qp[i, "Mu"], w.cla[,j], w.cla[,j+1], Mu, Cov)})
  Sig2.qp <- ms.qp[ind, "Sig2"]
  cbind(index = which(ind),  Sig2.cla, Sig2.qp,
        diff = Sig2.cla-Sig2.qp,  # Sig2.cla - Sig2.qp
        state = Sig2.cla-Sig2.qp > -1e-10 )
}

compareEF(w.qp, w.cla, Mu, Cov)


##
ind.list <- readRDS(d.file("ind_company.rds", exists = FALSE))  
#with length fibonacci(1457)$number, each sublist with 50 elements of corresponding length 



length(ind.list[[3]][[3]])
assign(paste("assets", 3, "_set", 3, sep = ""),
       readRDS(d.file(paste("assets", 3, "_set", 3, sep = ""), exists = FALSE)))

assets79 <- GetAssets(ind.list[[3]][[3]], assets1457)
compareEF(assets3_set3$weights$w.qp, assets3_set3$weights$w.cla,
          assets79$mu, assets79$covar)
f <- function(x,y) x+y
f(1,2)

