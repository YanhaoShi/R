if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################


plot_ms <- function(x,y, emph) {
  plot(x, y,      col = 2-emph, type="c", xlab = quote(sigma),ylab = quote(mu) ) # graph
  text(x, y, 1:n, col = 2-emph, cex = .75 ) 
  ch <- sort(chull(y, x))
  ch <- ch[x[ch]<= x[which.max(y)]] #remove points on right side of highest return point
  # str(ch)
  lines(x[ch], y[ch], lwd =2 , col=adjustcolor("blue",.5))
}

