if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
# 1) Preparing
#  save cla resulte(ver1, ver2) and cla time
for (m in seq(50, 1450, 50) ){
  if(!file.exists(d.file(paste("CLA_results", m, ".rds", sep =""),exists = FALSE))){
    CLA_analysis<- CLA_results(1:m, re = 10)
    CLA_time <- rbind(CLA_time, CLA_analysis$t)
    saveRDS(CLA_analysis, d.file(paste("CLA_results", m, ".rds", sep = ""), 
                                 exists = FALSE))
    saveRDS(GetAssets(seq(m), assets1457), d.file(paste("Company", m, ".rds", sep = ""), 
                                               exists = FALSE))
  }
}

# cla time
if(!file.exists(d.file("CLA_time.rds", exists = FALSE))){
  CLA_time <- t(sapply( seq(50, 1450, 50), function(m) 
    readRDS(d.file(paste("CLA_results", m, ".rds", sep =""),exists = FALSE))$t))
  row.names(CLA_time) <- seq(50, 1450, 50)
  saveRDS(CLA_time, d.file("CLA_time.rds", exists = FALSE))
}
CLA_time <- readRDS(d.file("CLA_time.rds", exists = FALSE))
##########################################################################
# 2) Ploting

# cla time plot
plot(seq(50, 1450, 50), CLA_time[,1], type = "o", pch = 16, xlab = "number of assets", 
     ylab = "millionseconds", col = "blue", ylim = range(CLA_time))
title("Time of CLA Versions")
lines(seq(50, 1450, 50), CLA_time[,2], col = "red", type = "o", pch =16)
legend("topleft", legend = c("PreviousVersion", "NewVersion"), lwd = 1, 
       col = c("blue", "red"), pch = 16)
#png(d.file("CLA_time_plot.png", exists = FALSE))

# cla time plot-log
plot(seq(50, 1450, 50), CLA_time[,1], type = "l", pch = 16, xlab = "number of assets", 
     ylab = "millionseconds", col = "blue", ylim = range(CLA_time), log = "y")
title("Logarithm Time of CLA Versions")
lines(seq(50, 1450, 50), CLA_time[,2], col = "red")
legend("topleft", legend = c("PreviousVersion", "MyVersion"), lwd = 1, col = c("blue", "red"))
#png(d.file("CLA_time_plot.png", exists = FALSE))

# number of weight sets
nweights <- numeric(0)
for(i in seq(50, 1450, 50)/50){
  nweights[i] <- ncol(readRDS(d.file(paste("CLA_results", i*50, ".rds", sep = ""), 
                                exists = FALSE))$r2$weights_set_purge)
}
nweights
plot(nweights, type = "o", pch = 16, xaxt = "n",
     xlab = "Number of Assets", ylab = "Number", 
     main = "Number of Weights Sets")
axis(1, at = 1: length(seq(50, 1450, 50)/50), labels = seq(50, 1450, 50) )


#########################################
CLA_results50 <- readRDS(d.file("CLA_results50.rds", exists = FALSE))
assets60 <- readRDS(d.file("assets60.rds", exists = FALSE))

weights.compare <- w.compare(assets60$mu, assets60$covar, 
                             assets60$lB, assets60$uB)

weights.micro <- weights.compare$micro
weights.list <- weights.compare$weights
weights.MS <- weights.compare$MS

# time: QP < CLA << CCCP

Total.plot(weights.MS)
# under a given risk, the expected return of the point on CLA EF are 
# generally slightly higher than expected return on quadratic EF.
# hard to observe on EF plot.

# Portgr returns positive weights (slightly) larger than lB or
# (slightly) smaller than uB, but not on the bounds
# Portgr requires given risks, hard to know the range of given risks
# CLA returns bounded weights exactly on uB or lB, but not work for small number of assets



kappa(assets50$covar)
ev <- eigen(assets_50$covar, only.values=TRUE)$values
plot(ev, log="y") #not too bad

r3 <-as.matrix(r_50[[3]])
ef <- efFrontier1(assets_50$mu, assets_50$covar, as.matrix(r_50[[3]]), 10)
ef1 <- efFrontier1(assets_50$mu, assets_50$covar, r2_50$solution_set,10)




 
