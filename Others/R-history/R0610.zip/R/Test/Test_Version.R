if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################


1/0.075
assets <- GetAssets(1:20, assets1457)
mu <- assets$mu; covar <- assets$covar; lB <- assets$lB; uB <- assets$uB


version.compare(50, times = 5)

lapply(seq(50, 250, 50), function(x) version.compare(x,times = 1)$is.equal)






r <- 
  CLA$M4(assets$mu, assets$covar, assets$lB, assets$uB)
r$weights_set[,1:4]

r2 <- CLA$M2(assets$mu, assets$covar, assets$lB, assets$uB)
r2$weights_set[,1:4]

plot(r$lambdas[-41], log = "y") # remove 0

length(assets$mu)

r50$weights_set_purge[,1:4]
plot(1:50, r50$weights_set_purge[,1], col = "black", pch = 16)
points(1:50, r50$weights_set_purge[,2], col = "red", pch = 16)
debugonce(CLA$M3)
CLA$M3(assets$mu, assets$covar, assets$lB, assets$uB)
