remove(list = ls())
source("Functions/Previous_Functions.R")
source("Functions/Previous_cla_solver_remove.R")
source("Functions/My_Functions.R")
source("Functions/My_cla_solver1_benchmark.R")
source("Functions/My_cla_solver2.R")
r_50 <- cla.solver(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)
r_50_unpurge <- cla.solver.remove(assets[[50]]$mu, assets[[50]]$covar, 
                                  assets[[50]]$lB, assets[[50]]$uB)


r1_50 <- cla.solver1(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)
r2_50 <- cla.solver2(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)
r2_50_purge <- r2_50[1:4]
r2_50_unpurge <- r2_50[5:8]




source("Functions/Ver1_previous.R")
mr_50 <- Method1$cla.solver(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)

mr_50_unpurge <- Method1$cla.solver.unpurge(assets[[50]]$mu, assets[[50]]$covar, 
                          assets[[50]]$lB, assets[[50]]$uB)
source("Functions/Ver2.R")
mr1_50 <- Method2$cla.solver(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)

mr1_50_unpurge <- Method2$cla.solver.unpurge(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)

mr1_50_unpurge$solution_set

source("Functions/Ver3.R")
mr2_50 <- Method3$cla.solver(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)
mr2_50_unpurge <- mr2_50[5:8]
# version 1 validation
all.equal(r_50, mr_50)
all.equal(r_50_unpurge, mr_50_unpurge)

# version 2 validation
all.equal(r1_50, mr1_50)
all.equal(r2_50_unpurge, mr1_50_unpurge)

# version 3 validation
all.equal(r2_50_unpurge, mr2_50_unpurge)

# version 2 and version 3 have same cla results
all.equal(r2_50_purge, r1_50)


