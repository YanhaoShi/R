if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
# Compare results
r_50 <- cla.solver(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)
r_50_unpurge <- cla.solver.remove(assets[[50]]$mu, assets[[50]]$covar, 
                                  assets[[50]]$lB, assets[[50]]$uB)

r1_50 <- cla.solver1(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)
r2_50 <- cla.solver2(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB)
r2_50_purge <- r2_50[1:4]
r2_50_unpurge <- r2_50[5:8]

#all.equal(r_50_unpurge, r2_50_unpurge, check.names = FALSE)
all.equal(r1_50, r2_50_purge, check.names = FALSE)



microbenchmark(r_50 = cla.solver(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB),
               r1_50 = cla.solver1(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB),
               r2_50 = cla.solver2(assets[[50]]$mu, assets[[50]]$covar, assets[[50]]$lB, assets[[50]]$uB),
               times = 3)


analysis <- function(assets, re = 100){  # re: repeat times
  micro <- microbenchmark(
    r0 <- cla.solver(assets$mu, assets$covar, assets$lB, assets$uB),
    r1 <- cla.solver1(assets$mu, assets$covar, assets$lB, assets$uB),
    r2 <- cla.solver2(assets$mu, assets$covar, assets$lB, assets$uB), times = re) 
  t0 <- median(micro$time[1:re])
  t1 <- median(micro$time[(re + 1):(2*re)])
  t2 <- median(micro$time[(2*re +1):(3*re)])
  list(r0 = r0, r1 = r1, r2 = r2,  # cla.solver results
       t0 = t0, t1 = t1, t2 = t2)  # times
  
}

analysis_result <- list()
for (n in 15:500){
  analysis_result[[n]] <- analysis(get(paste("assets", n, sep ="")), 20)
}
saveRDS(analysis_result, d.file("analysis_result.rds", exists = FALSE))


cla_time <- data.frame(t0 = c(), t1 = c(), t2 = c())
for(n in 15:450){
 cla_time[n, "t0"] <- analysis_result[[n]]$t0
 cla_time[n, "t1"] <- analysis_result[[n]]$t1
 cla_time[n, "t2"] <- analysis_result[[n]]$t2
}
cla_time

plot(x = c(1:450), y = cla_time$t0, col = "gray", type = "l", pch = 16, ylim = c(0, 1e7))
points(cla_time$t1, col = "red", type = "l", pch = 16)
points(cla_time$t2, col = "blue", type = "l", pch = 16)





#########################################

kappa(assets50$covar)
ev <- eigen(assets_50$covar, only.values=TRUE)$values
plot(ev, log="y") #not too bad

r3 <-as.matrix(r_50[[3]])
ef <- efFrontier1(assets_50$mu, assets_50$covar, as.matrix(r_50[[3]]), 10)
ef1 <- efFrontier1(assets_50$mu, assets_50$covar, r2_50$solution_set,10)


plot( ef$sigma, ef$mu,type = "l", col = "gray") 
points(ef1$sigma, ef1$mu, col = "red", pch = 16, cex = 0.25)


new <- order(ef1$mu)
plot( ef1$sigma, ef1$mu,type = "l", col = "gray",
      xlab = "sigma", ylab = "mean") 
points(ef1$sigma, ef1$mu, col = "red", pch = 16, cex = 0.25)
points(sqrt(diag(t(r2_50$solution_set) %*% assets_50$covar %*% r2_50$solution_set)),
     t(assets_50$mu) %*% r2_50$solution_set, pch = 16, col = "blue", cex = 0.5)









##

plot(diag(t(r3) %*% assets_50$covar %*% r3),
     t(assets_50$mu) %*% r3)
points(sqrt(diag(assets_50$covar)), assets_50$mu, col = "blue" )


 
