if(!file.exists("main.R")) stop("R directory does *not* contain main.R")
source("main.R")
########################################################################
r2_50$covarF



cov.kappa <- sapply(r2_50$covarF, kappa)
plot(cov.kappa, type = "o", main = "kappa")

cov.m <- lapply(r2_50$covarF, as.matrix)
sapply(cov.m, rcond)
lapply(cov.m, nearPD)


assets500 <- readRDS(d.file("assets500.rds", exists = FALSE))
r2_500 <- cla.solver2(assets500$mu, assets500$covar, assets500$lB, assets500$uB)


cov.kappa500 <- sapply(r2_500$covarF, kappa)
plot(cov.kappa500, type = "o", main = "kappa")




















s <- matrix(c(1,2,2,1),2,2)
rcond(s)
kappa(s)
nearPD(s)
posdefify
norm(s, "F")
norm(solve(s), "F")

1/norm(s)
norm(solve(s))
eigen(s)






