#benchmark, do not change!

cla.solver1 <- function(mean, covar,lB, uB){                                             
  # Compute the turning points,free sets and weights
  f <- initAlgo1(mean, lB, uB)$index
  w <- as.matrix(initAlgo1(mean, lB, uB)$weights)
  solution_set <- w # store solution
  lambdas <-  c()
  gammas <- c()
  free_weights <- list(f) ### 
  list_temp <- c() 
  while ( TRUE ) {
    # 1) case a): Bound one free weight 
    l_in <- 0
    temp_getMat1 <- getMatrices1(mean, covar,solution_set, f)
    covarF1 <- temp_getMat1$covarF
    covarFB1 <- temp_getMat1$covarFB
    meanF1 <- temp_getMat1$meanF
    wB1 <- temp_getMat1$wB
    if(length(f) > 1){  
      j <- 1
      for (i1 in f) {
        temp_compLam <- computeLambda1(covarFB1,meanF1,wB1,j,
                                       as.list(c(lB[i1],uB[i1])),covarF1)
        l1 <- temp_compLam$lambda 
        bi <- temp_compLam$bi 
        if( l1 > l_in  ){  
          l_in <- l1
          i_in <- i1
          bi_in <- bi   
        }
        j <- j + 1
      }
    }  
    # 2) case b): Free one bounded weight
    l_out <- 0
    if(length(f) < length(mean)) {
      
      b <- (1:length(mean))[-f]
      for(i in b){
        temp_getMat2 <- getMatrices1(mean, covar,solution_set, c(f,i))
        covarF2 <- temp_getMat2$covarF
        covarFB2 <- temp_getMat2$covarFB
        meanF2 <- temp_getMat2$meanF
        wB2 <- temp_getMat2$wB
        temp_compLam <- computeLambda1(covarFB2,meanF2,wB2,length(meanF2),
                                       solution_set[i,ncol(solution_set)],covarF2)
        l2 <- temp_compLam$lambda 
        bi <- temp_compLam$bi
        
        if ((length(lambdas)==0 || l2<lambdas[length(lambdas)]) && (l2>l_out)){
          l_out <- l2
          i_out <- i
          temp_getMat_out <- temp_getMat2
        }
      }
    }
    
    if( (l_in <= 0) & (l_out <= 0) ) { # "stop" when at the min var solution! 
      
      # 3) compute minimum variance solution
      lambdas <- c(lambdas,0)
      meanF <- matrix(0,length(meanF))
      temp_compW <- computeW1(lambdas,covarFB1,meanF,wB1,covarF1)
      wF <- temp_compW$wF
      g <- temp_compW$gamma
      
      list_temp <- c(list_temp, list(temp_getMat1))
      
      for(i in seq(length(f))){
        w[f[i]]=wF[i]
      }
      solution_set <- cbind(solution_set, w) # store solution
      gammas <- c(gammas, g)
      break
      
    } else {
      
      # 4) decide lambda       
      if(l_in>l_out){ 
        lambdas <- c(lambdas,l_in)
        f <- f[f != i_in] # remove i_in within f
        w[i_in] = bi_in # set value at the correct boundary
        temp_getMat1 <- getMatrices1(mean, covar,solution_set, f)
        covarF <- temp_getMat1$covarF
        covarFB <- temp_getMat1$covarFB
        meanF <- temp_getMat1$meanF
        wB <- temp_getMat1$wB
        temp_compW <- computeW1(lambdas,covarFB,meanF,wB,covarF)
        wF <- temp_compW$wF
        g <- temp_compW$gamma 
        
        
      }else{
        lambdas <- c(lambdas,l_out)
        f <- c(f,i_out) # append i_out into f
        
        temp_getMat1 <- temp_getMat_out
        covarF <- temp_getMat1$covarF
        covarFB <- temp_getMat1$covarFB
        meanF <- temp_getMat1$meanF
        wB <- temp_getMat1$wB
        temp_compW <- computeW1(lambdas,covarFB,meanF,wB,covarF)
        wF <- temp_compW$wF
        g <- temp_compW$gamma
      }
      
      
      for(i in seq(length(f))){
        w[f[i]]=wF[i]
      }
      
      solution_set <- cbind(solution_set, w) # store solution
      gammas <- c(gammas, g)
      free_weights <- c(free_weights, list(f))
      
    }
    
  } #end While  
  lambdas <- c(NA, lambdas) #The first step has no lambda or gamma, add NA instead
  gammas <- c(NA, gammas)
  free_weights <- c(free_weights, NA) # The last step stop without weight set, add NA.
  
  i <- purgeNummErr1(lB, uB, solution_set, 1e-9, 1e-10) 
  solution_set <- solution_set[,-i]
  lambdas <- lambdas[-i]
  gammas <- gammas[-i]
  free_weights <- free_weights[-i]
  
  k <- purgeExcess1(mean, solution_set, 1e-12)
  solution_set <- solution_set[,-k] 
  lambdas <- lambdas[-k] 
  gammas <- gammas[-k]
  free_weights <- free_weights[-k] 
  
  list(solution_set = solution_set, free_indices=free_weights, 
       gammas = gammas, lambdas = lambdas)
  
}